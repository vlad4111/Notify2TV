package com.vlad411.notify2tv

import android.app.UiModeManager
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.vlad411.notify2tv.service.TvReceiverManager
import com.vlad411.notify2tv.service.TvServerService
import com.vlad411.notify2tv.ui.MobileMainScreen
import com.vlad411.notify2tv.ui.theme.Notify2TVTheme
import com.vlad411.notify2tv.ui.tv.TvMainScreen

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val isTvDevice = runCatching { checkIsTvDevice() }.getOrDefault(false)
        val prefs = runCatching { getSharedPreferences("notify2tv_app_prefs", MODE_PRIVATE) }.getOrNull()
        // Mobile companion app is the default primary screen unless running on Android TV hardware
        val defaultMode = if (isTvDevice) "TV" else "MOBILE"
        val savedMode = prefs?.getString("app_mode", defaultMode) ?: defaultMode

        if (isTvDevice || savedMode == "TV") {
            runCatching { TvServerService.startService(applicationContext) }
        }

        setContent {
            Notify2TVTheme {
                var currentMode by remember { mutableStateOf(savedMode) }
                val receiverManager = remember { TvReceiverManager.getInstance(applicationContext) }

                val lifecycleOwner = LocalLifecycleOwner.current
                DisposableEffect(lifecycleOwner) {
                    val observer = LifecycleEventObserver { _, event ->
                        when (event) {
                            Lifecycle.Event.ON_START, Lifecycle.Event.ON_RESUME -> {
                                receiverManager.setAppInForeground(true)
                            }
                            Lifecycle.Event.ON_STOP -> {
                                receiverManager.setAppInForeground(false)
                            }
                            else -> {}
                        }
                    }
                    lifecycleOwner.lifecycle.addObserver(observer)
                    onDispose {
                        lifecycleOwner.lifecycle.removeObserver(observer)
                        receiverManager.setAppInForeground(false)
                    }
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        if (currentMode == "TV") {
                            TvMainScreen(
                                onSwitchToMobile = {
                                    currentMode = "MOBILE"
                                    runCatching { prefs?.edit()?.putString("app_mode", "MOBILE")?.apply() }
                                }
                            )
                        } else {
                            MobileMainScreen(
                                onSwitchToTvMode = {
                                    currentMode = "TV"
                                    runCatching { prefs?.edit()?.putString("app_mode", "TV")?.apply() }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        TvReceiverManager.getInstance(applicationContext).setAppInForeground(true)
    }

    override fun onResume() {
        super.onResume()
        TvReceiverManager.getInstance(applicationContext).setAppInForeground(true)
    }

    override fun onStop() {
        super.onStop()
        TvReceiverManager.getInstance(applicationContext).setAppInForeground(false)
    }

    private fun checkIsTvDevice(): Boolean {
        return runCatching {
            val uiModeManager = getSystemService(UI_MODE_SERVICE) as? UiModeManager
            if (uiModeManager?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION) {
                return true
            }
            if (packageManager.hasSystemFeature("android.software.leanback_launcher") ||
                packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
                @Suppress("DEPRECATION")
                packageManager.hasSystemFeature(PackageManager.FEATURE_TELEVISION)
            ) {
                return true
            }
            false
        }.getOrDefault(false)
    }
}
