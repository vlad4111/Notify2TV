package com.vlad411.notify2tv.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class NotificationActionPayload(
    @SerialName("action_id") val actionId: String,
    @SerialName("title") val title: String,
    @SerialName("is_quick_reply") val isQuickReply: Boolean = false
)

@Serializable
data class NotificationPayload(
    @SerialName("id") val id: String,
    @SerialName("app_name") val appName: String,
    @SerialName("package_name") val packageName: String,
    @SerialName("title") val title: String,
    @SerialName("body") val body: String,
    @SerialName("timestamp") val timestamp: Long = System.currentTimeMillis(),
    @SerialName("app_icon_base64") val appIconBase64: String? = null,
    @SerialName("big_picture_base64") val bigPictureBase64: String? = null,
    @SerialName("category") val category: String? = null,
    @SerialName("priority") val priority: Int = 0,
    @SerialName("actions") val actions: List<NotificationActionPayload> = emptyList(),
    @SerialName("is_clearable") val isClearable: Boolean = true,
    @SerialName("group_key") val groupKey: String? = null
)
