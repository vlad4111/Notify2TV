package com.vlad411.notify2tv.model

import android.view.Gravity
import androidx.compose.ui.Alignment

enum class BannerPosition(
    val displayName: String,
    val alignment: Alignment,
    val gravity: Int
) {
    TOP_LEFT("Top Left", Alignment.TopStart, Gravity.TOP or Gravity.START),
    TOP_RIGHT("Top Right", Alignment.TopEnd, Gravity.TOP or Gravity.END),
    BOTTOM_LEFT("Bottom Left", Alignment.BottomStart, Gravity.BOTTOM or Gravity.START),
    BOTTOM_RIGHT("Bottom Right", Alignment.BottomEnd, Gravity.BOTTOM or Gravity.END)
}
