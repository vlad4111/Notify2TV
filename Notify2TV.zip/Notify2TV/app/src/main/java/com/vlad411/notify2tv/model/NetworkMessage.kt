package com.vlad411.notify2tv.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

private val jsonFormatter = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
    isLenient = true
}

@Serializable
sealed interface NetworkMessage {
    val timestamp: Long

    @Serializable
    @SerialName("notification")
    data class Notification(
        @SerialName("payload") val payload: NotificationPayload,
        @SerialName("timestamp") override val timestamp: Long = System.currentTimeMillis()
    ) : NetworkMessage

    @Serializable
    @SerialName("call")
    data class Call(
        @SerialName("payload") val payload: CallPayload,
        @SerialName("timestamp") override val timestamp: Long = System.currentTimeMillis()
    ) : NetworkMessage

    @Serializable
    @SerialName("pairing_request")
    data class PairingRequest(
        @SerialName("payload") val payload: PairingPayload,
        @SerialName("timestamp") override val timestamp: Long = System.currentTimeMillis()
    ) : NetworkMessage

    @Serializable
    @SerialName("pairing_response")
    data class PairingResponse(
        @SerialName("payload") val payload: PairingPayload,
        @SerialName("accepted") val accepted: Boolean,
        @SerialName("message") val message: String? = null,
        @SerialName("timestamp") override val timestamp: Long = System.currentTimeMillis()
    ) : NetworkMessage

    @Serializable
    @SerialName("action")
    data class Action(
        @SerialName("action_id") val actionId: String,
        @SerialName("notification_id") val notificationId: String,
        @SerialName("reply_text") val replyText: String? = null,
        @SerialName("timestamp") override val timestamp: Long = System.currentTimeMillis()
    ) : NetworkMessage

    @Serializable
    @SerialName("ping")
    data class Ping(
        @SerialName("timestamp") override val timestamp: Long = System.currentTimeMillis()
    ) : NetworkMessage

    @Serializable
    @SerialName("pong")
    data class Pong(
        @SerialName("timestamp") override val timestamp: Long = System.currentTimeMillis()
    ) : NetworkMessage

    @Serializable
    @SerialName("disconnect")
    data class Disconnect(
        @SerialName("reason") val reason: String? = null,
        @SerialName("timestamp") override val timestamp: Long = System.currentTimeMillis()
    ) : NetworkMessage

    @Serializable
    @SerialName("banner_position_update")
    data class BannerPositionUpdate(
        @SerialName("position") val position: String,
        @SerialName("timestamp") override val timestamp: Long = System.currentTimeMillis()
    ) : NetworkMessage

    @Serializable
    @SerialName("banner_transparency_update")
    data class BannerTransparencyUpdate(
        @SerialName("percent") val percent: Int,
        @SerialName("timestamp") override val timestamp: Long = System.currentTimeMillis()
    ) : NetworkMessage

    @Serializable
    @SerialName("banner_timeout_update")
    data class BannerTimeoutUpdate(
        @SerialName("seconds") val seconds: Int,
        @SerialName("timestamp") override val timestamp: Long = System.currentTimeMillis()
    ) : NetworkMessage

    fun toJson(): String = jsonFormatter.encodeToString(this)

    companion object {
        fun fromJson(jsonString: String): NetworkMessage? {
            return runCatching { jsonFormatter.decodeFromString<NetworkMessage>(jsonString) }.getOrNull()
        }
    }
}
