package com.vlad411.notify2tv.network

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.net.Inet4Address
import java.net.NetworkInterface

object NetworkUtils {
    const val DEFAULT_PORT = 8080
    const val WS_PATH = "/notify2tv"

    fun getLocalIpAddress(): String? {
        runCatching {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                if (networkInterface.isLoopback || !networkInterface.isUp) continue

                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (address is Inet4Address && !address.isLoopbackAddress) {
                        return address.hostAddress
                    }
                }
            }
        }
        return null
    }

    fun bitmapToBase64(bitmap: Bitmap, quality: Int = 80): String {
        return runCatching {
            val byteArrayOutputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, quality, byteArrayOutputStream)
            val byteArray = byteArrayOutputStream.toByteArray()
            Base64.encodeToString(byteArray, Base64.NO_WRAP)
        }.getOrDefault("")
    }

    fun base64ToBitmap(base64Str: String): Bitmap? {
        if (base64Str.isBlank()) return null
        return runCatching {
            val decodedBytes = Base64.decode(base64Str, Base64.DEFAULT)
            if (decodedBytes.isEmpty()) return null
            BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
        }.getOrNull()
    }
}
