package com.vlad411.notify2tv.service

import android.app.Notification
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TvNotificationListenerServiceTest {

    @Test
    fun testPersistentNotificationFlagCheck() {
        val ongoingFlag = Notification.FLAG_ONGOING_EVENT
        val noClearFlag = Notification.FLAG_NO_CLEAR
        val foregroundFlag = Notification.FLAG_FOREGROUND_SERVICE

        val mask = Notification.FLAG_ONGOING_EVENT or Notification.FLAG_NO_CLEAR or Notification.FLAG_FOREGROUND_SERVICE

        assertTrue((ongoingFlag and mask) != 0)
        assertTrue((noClearFlag and mask) != 0)
        assertTrue((foregroundFlag and mask) != 0)
        assertTrue(((ongoingFlag or noClearFlag) and mask) != 0)

        val regularNotificationFlags = 0
        assertFalse((regularNotificationFlags and mask) != 0)
    }
}
