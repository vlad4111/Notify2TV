package com.vlad411.notify2tv.receiver

import com.vlad411.notify2tv.model.CallPayload
import com.vlad411.notify2tv.model.CallType
import com.vlad411.notify2tv.model.NetworkMessage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class PhoneCallReceiverTest {

    @Test
    fun testIncomingCallPayloadCreation() {
        val payload = CallPayload(
            id = "call_12345",
            callType = CallType.INCOMING,
            callerName = "Alice Smith",
            callerNumber = "+15550199",
            callerAvatarBase64 = null
        )

        assertEquals("call_12345", payload.id)
        assertEquals(CallType.INCOMING, payload.callType)
        assertEquals("Alice Smith", payload.callerName)
        assertEquals("+15550199", payload.callerNumber)

        val message = NetworkMessage.Call(payload)
        val json = message.toJson()
        val decoded = NetworkMessage.fromJson(json) as? NetworkMessage.Call

        assertNotNull(decoded)
        assertEquals(CallType.INCOMING, decoded?.payload?.callType)
        assertEquals("Alice Smith", decoded?.payload?.callerName)
    }

    @Test
    fun testCallStateTransitions() {
        val states = mutableListOf<CallType>()

        // Simulated incoming call -> ringing
        states.add(CallType.INCOMING)
        // Simulated missed call -> idle without answering
        states.add(CallType.MISSED)

        assertEquals(2, states.size)
        assertEquals(CallType.INCOMING, states[0])
        assertEquals(CallType.MISSED, states[1])
    }
}
