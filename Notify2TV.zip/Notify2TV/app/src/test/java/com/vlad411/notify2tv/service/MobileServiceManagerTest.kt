package com.vlad411.notify2tv.service

import com.vlad411.notify2tv.model.CallType
import com.vlad411.notify2tv.model.NotificationPayload
import com.vlad411.notify2tv.model.PairingPayload
import com.vlad411.notify2tv.model.PairingStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MobileServiceManagerTest {

    @Test
    fun testLogEntryCreationAndCap() {
        val manager = TestLogManager()

        assertEquals(0, manager.logs.size)

        manager.addLog(LogType.NOTIFICATION, "Test App", "Test Message", LogStatus.SENT)
        assertEquals(1, manager.logs.size)
        assertEquals("Test App", manager.logs[0].title)
        assertEquals(LogStatus.SENT, manager.logs[0].status)

        for (i in 1..150) {
            manager.addLog(LogType.SYSTEM, "System event $i", "Details", LogStatus.INFO)
        }

        assertTrue(manager.logs.size <= 100)
        assertEquals("System event 150", manager.logs[0].title)

        manager.clearLogs()
        assertEquals(0, manager.logs.size)
    }

    @Test
    fun testPairingStatusTransitions() {
        val initialStatus = PairingStatus.PENDING
        assertEquals(PairingStatus.PENDING, initialStatus)

        val updatedStatus = PairingStatus.ACCEPTED
        assertEquals(PairingStatus.ACCEPTED, updatedStatus)
    }

    private class TestLogManager {
        val logs = mutableListOf<ForwardingLogEntry>()

        fun addLog(type: LogType, title: String, description: String, status: LogStatus) {
            val entry = ForwardingLogEntry(
                type = type,
                title = title,
                description = description,
                status = status
            )
            logs.add(0, entry)
            if (logs.size > 100) {
                logs.removeAt(logs.size - 1)
            }
        }

        fun clearLogs() {
            logs.clear()
        }
    }
}
