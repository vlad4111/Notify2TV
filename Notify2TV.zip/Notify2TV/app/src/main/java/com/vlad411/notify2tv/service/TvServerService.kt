package com.vlad411.notify2tv.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.vlad411.notify2tv.MainActivity
import com.vlad411.notify2tv.R

class TvServerService : Service() {

    private lateinit var tvReceiverManager: TvReceiverManager

    companion object {
        private const val TAG = "TvServerService"
        const val CHANNEL_ID = "tv_receiver_service_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "com.vlad411.notify2tv.ACTION_START_TV_SERVER"
        const val ACTION_STOP = "com.vlad411.notify2tv.ACTION_STOP_TV_SERVER"

        fun startService(context: Context) {
            val intent = Intent(context, TvServerService::class.java).apply {
                action = ACTION_START
            }
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }.onFailure { e ->
                Log.e(TAG, "Failed to start foreground service: ${e.localizedMessage}", e)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, TvServerService::class.java).apply {
                action = ACTION_STOP
            }
            runCatching {
                context.startService(intent)
            }.onFailure { e ->
                Log.e(TAG, "Failed to stop service: ${e.localizedMessage}", e)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        tvReceiverManager = TvReceiverManager.getInstance(applicationContext)
        runCatching { createNotificationChannel() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            runCatching { tvReceiverManager.stopServer() }
            runCatching { TvSystemOverlayManager.hideOverlay(applicationContext) }
            runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
            stopSelf()
            return START_NOT_STICKY
        }

        runCatching {
            val notification = createNotification()
            startForeground(NOTIFICATION_ID, notification)
        }.onFailure { e ->
            Log.e(TAG, "Failed to startForeground notification: ${e.localizedMessage}", e)
        }

        runCatching {
            tvReceiverManager.startServer()
        }.onFailure { e ->
            Log.e(TAG, "Failed to start TV WebSocket server: ${e.localizedMessage}", e)
        }

        return START_STICKY
    }

    override fun onDestroy() {
        runCatching { tvReceiverManager.stopServer() }
        runCatching { TvSystemOverlayManager.hideOverlay(applicationContext) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Notify2TV Receiver Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps TV WebSocket server running for incoming mobile alerts"
                setShowBadge(false)
                enableVibration(false)
                setSound(null, null)
            }
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, TvServerService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Notify2TV Receiver Active")
            .setContentText("Listening on port 8080 for phone notifications & call alerts")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pendingIntent)
            .addAction(0, "Stop Receiver", stopPendingIntent)
            .build()
    }
}
