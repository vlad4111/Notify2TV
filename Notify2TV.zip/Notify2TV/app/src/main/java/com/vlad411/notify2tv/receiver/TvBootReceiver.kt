package com.vlad411.notify2tv.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.vlad411.notify2tv.service.TvServerService

class TvBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            TvServerService.startService(context)
        }
    }
}
