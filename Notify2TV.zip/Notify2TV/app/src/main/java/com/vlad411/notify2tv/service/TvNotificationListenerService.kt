package com.vlad411.notify2tv.service

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.vlad411.notify2tv.model.NetworkMessage
import com.vlad411.notify2tv.model.NotificationActionPayload
import com.vlad411.notify2tv.model.NotificationPayload
import com.vlad411.notify2tv.network.NetworkUtils
import com.vlad411.notify2tv.util.CameraNotificationDetector

class TvNotificationListenerService : NotificationListenerService() {

    private data class CachedAction(
        val notificationKey: String,
        val action: Notification.Action
    )

    private val activeActionsMap = mutableMapOf<String, CachedAction>()

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "TvNotificationListenerService created")
        val serviceManager = MobileServiceManager.getInstance(this)
        serviceManager.actionHandler = { actionMessage ->
            handleNotificationAction(actionMessage)
        }
    }

    fun isPersistentNotification(sbn: StatusBarNotification): Boolean {
        if (sbn.isOngoing) return true
        val notification = sbn.notification ?: return false
        val flags = notification.flags
        val persistentMask = Notification.FLAG_ONGOING_EVENT or Notification.FLAG_NO_CLEAR or Notification.FLAG_FOREGROUND_SERVICE
        return (flags and persistentMask) != 0
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        // Filter out ONLY our app's own notifications (e.g. ongoing foreground service)
        if (sbn.packageName == packageName) return

        val serviceManager = MobileServiceManager.getInstance(applicationContext)

        if (serviceManager.isIgnorePersistentEnabled.value && isPersistentNotification(sbn)) {
            val title = sbn.notification?.extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString()
                ?: sbn.notification?.extras?.getCharSequence(Notification.EXTRA_TITLE_BIG)?.toString()
                ?: ""
            val appName = try {
                val appInfo = packageManager.getApplicationInfo(sbn.packageName, 0)
                packageManager.getApplicationLabel(appInfo).toString()
            } catch (e: Exception) {
                sbn.packageName
            }
            val displayTitle = title.ifBlank { "Notification" }
            serviceManager.addLog(
                LogType.NOTIFICATION,
                "Ignored persistent notification from $appName: $displayTitle",
                "Ongoing / persistent notification filtered out according to settings.",
                LogStatus.INFO
            )
            return
        }

        try {
            val payload = extractNotificationPayload(sbn)
            if (payload != null) {
                val isCamera = CameraNotificationDetector.isCameraNotification(payload)
                val hasImage = !payload.bigPictureBase64.isNullOrBlank()
                serviceManager.addLog(
                    LogType.NOTIFICATION,
                    "Captured notification from ${payload.appName}: ${payload.title} (ImageAttached: $hasImage, CameraDetected: $isCamera)",
                    payload.body.ifBlank { "(No content text)" },
                    LogStatus.INFO
                )
                serviceManager.sendNotification(payload)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error extracting notification: ${e.localizedMessage}", e)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val notifKey = sbn.key
        activeActionsMap.entries.removeIf { it.value.notificationKey == notifKey }
    }

    fun extractNotificationPayload(sbn: StatusBarNotification): NotificationPayload? {
        val notification = sbn.notification ?: return null
        val extras = notification.extras ?: Bundle()

        val packageName = sbn.packageName ?: "unknown"
        val notifId = "${packageName}_${sbn.id}_${sbn.tag ?: ""}"

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TITLE_BIG)?.toString()
            ?: extras.getCharSequence("android.conversationTitle")?.toString()
            ?: ""

        val bodyLines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.joinToString("\n")

        val body = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()
            ?: bodyLines
            ?: extras.getCharSequence(Notification.EXTRA_INFO_TEXT)?.toString()
            ?: ""

        if (title.isBlank() && body.isBlank()) {
            return null
        }

        val displayTitle = title.ifBlank { "Notification" }

        val appName = try {
            val appInfo = packageManager.getApplicationInfo(packageName, 0)
            packageManager.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            packageName
        }

        // App Icon
        val appIconBase64 = extractAppIconBase64(sbn, notification)

        // Big Picture / Attachment Image
        var bigPictureBase64 = extractBigPictureBase64(notification, extras)

        // Check if camera notification
        val isCamera = CameraNotificationDetector.isCameraNotification(
            packageName = packageName,
            appName = appName,
            title = displayTitle,
            body = body
        )

        // Fallback bigPictureBase64 to appIconBase64 if it's a camera notification and picture was not in extras
        if (bigPictureBase64.isNullOrBlank() && isCamera && !appIconBase64.isNullOrBlank()) {
            bigPictureBase64 = appIconBase64
        }

        // Actions
        val actionPayloads = mutableListOf<NotificationActionPayload>()
        val actions = notification.actions
        if (actions != null) {
            for (i in actions.indices) {
                val action = actions[i]
                val actionTitle = action.title?.toString() ?: "Action $i"
                val actionId = "${notifId}_action_$i"
                val isQuickReply = action.remoteInputs?.isNotEmpty() == true

                actionPayloads.add(
                    NotificationActionPayload(
                        actionId = actionId,
                        title = actionTitle,
                        isQuickReply = isQuickReply
                    )
                )

                activeActionsMap[actionId] = CachedAction(sbn.key, action)
            }
        }

        return NotificationPayload(
            id = notifId,
            appName = appName,
            packageName = packageName,
            title = displayTitle,
            body = body,
            timestamp = sbn.postTime,
            appIconBase64 = appIconBase64,
            bigPictureBase64 = bigPictureBase64,
            category = notification.category,
            priority = notification.priority,
            actions = actionPayloads,
            isClearable = sbn.isClearable,
            groupKey = sbn.groupKey
        )
    }

    private fun extractAppIconBase64(sbn: StatusBarNotification, notification: Notification): String? {
        return try {
            val largeIcon = notification.getLargeIcon()
            val bitmap = extractBitmapFromIconOrParcelable(this, largeIcon)
                ?: runCatching {
                    val drawable = packageManager.getApplicationIcon(sbn.packageName)
                    drawableToBitmap(drawable)
                }.getOrNull()

            if (bitmap != null) {
                NetworkUtils.bitmapToBase64(bitmap, quality = 70)
            } else null
        } catch (e: Exception) {
            null
        }
    }

    @Suppress("DEPRECATION")
    private fun extractBigPictureBase64(notification: Notification, extras: Bundle): String? {
        val candidates = mutableListOf<Any?>()

        // a) Notification.EXTRA_PICTURE / "android.picture"
        candidates.add(extras.get(Notification.EXTRA_PICTURE))
        candidates.add(extras.get("android.picture"))

        // b) Notification.EXTRA_PICTURE_ICON / "android.pictureIcon"
        candidates.add(extras.get("android.pictureIcon"))

        // c) Notification.EXTRA_LARGE_ICON_BIG / "android.largeIcon.big" & Notification.EXTRA_LARGE_ICON
        candidates.add(extras.get("android.largeIcon.big"))
        candidates.add(extras.get(Notification.EXTRA_LARGE_ICON))
        candidates.add(extras.get("android.largeIcon"))

        // d) sbn.notification.getLargeIcon()
        candidates.add(notification.getLargeIcon())

        // e) Notification.EXTRA_BACKGROUND_IMAGE / "android.backgroundImage"
        candidates.add(extras.get("android.backgroundImage"))

        // Additional fallbacks
        candidates.add(extras.get("android.bigLargeIcon"))
        candidates.add(extras.get("android.templateIcon"))

        for (candidate in candidates) {
            if (candidate == null) continue
            val bitmap = extractBitmapFromIconOrParcelable(this, candidate)
            if (bitmap != null && bitmap.width > 0 && bitmap.height > 0) {
                val base64 = NetworkUtils.bitmapToBase64(bitmap, quality = 75)
                if (!base64.isNullOrBlank()) {
                    return base64
                }
            }
        }
        return null
    }

    fun extractBitmapFromIconOrParcelable(context: Context, obj: Any?): Bitmap? {
        if (obj == null) return null
        return try {
            when (obj) {
                is Bitmap -> {
                    if (!obj.isRecycled && obj.width > 0 && obj.height > 0) obj else null
                }
                is Icon -> {
                    val drawable = runCatching { obj.loadDrawable(context) }.getOrNull()
                    drawable?.let { drawableToBitmap(it) }
                }
                is Drawable -> drawableToBitmap(obj)
                is Uri -> {
                    context.contentResolver.openInputStream(obj)?.use { inputStream ->
                        BitmapFactory.decodeStream(inputStream)
                    }
                }
                is String -> {
                    if (obj.startsWith("content://") || obj.startsWith("file://")) {
                        val uri = Uri.parse(obj)
                        context.contentResolver.openInputStream(uri)?.use { inputStream ->
                            BitmapFactory.decodeStream(inputStream)
                        }
                    } else null
                }
                is ByteArray -> {
                    if (obj.isNotEmpty()) {
                        BitmapFactory.decodeByteArray(obj, 0, obj.size)
                    } else null
                }
                else -> null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to extract bitmap from ${obj.javaClass.simpleName}: ${e.message}")
            null
        }
    }

    private fun handleNotificationAction(actionMessage: NetworkMessage.Action) {
        val cachedAction = activeActionsMap[actionMessage.actionId] ?: return
        val action = cachedAction.action

        try {
            if (!actionMessage.replyText.isNullOrBlank() && action.remoteInputs != null && action.remoteInputs.isNotEmpty()) {
                val intent = Intent()
                val bundle = Bundle()
                for (remoteInput in action.remoteInputs) {
                    bundle.putCharSequence(remoteInput.resultKey, actionMessage.replyText)
                }
                RemoteInput.addResultsToIntent(action.remoteInputs, intent, bundle)
                action.actionIntent.send(this, 0, intent)
                Log.d(TAG, "Sent quick reply for action ${actionMessage.actionId}")
            } else {
                action.actionIntent.send()
                Log.d(TAG, "Executed action intent for ${actionMessage.actionId}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to execute notification action: ${e.localizedMessage}", e)
        }
    }

    private fun drawableToBitmap(drawable: Drawable): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null && !drawable.bitmap.isRecycled) {
            return drawable.bitmap
        }
        val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth.coerceAtMost(1024) else 256
        val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight.coerceAtMost(1024) else 256
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }

    companion object {
        private const val TAG = "TvNotificationListener"
    }
}
