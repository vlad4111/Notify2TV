package com.vlad411.notify2tv.ui.tv

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CellTower
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Tv
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.zIndex
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Slider
import kotlin.math.roundToInt
import com.vlad411.notify2tv.model.BannerPosition
import com.vlad411.notify2tv.network.NetworkUtils
import com.vlad411.notify2tv.network.ServerState
import android.widget.Toast
import androidx.compose.runtime.rememberCoroutineScope
import com.vlad411.notify2tv.service.PairedDeviceInfo
import com.vlad411.notify2tv.service.TvSystemOverlayManager
import com.vlad411.notify2tv.service.TvReceiverManager
import com.vlad411.notify2tv.service.TvServerService
import com.vlad411.notify2tv.ui.overlay.TvOverlayBanner
import com.vlad411.notify2tv.util.QrCodeGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

import androidx.compose.material.icons.rounded.Videocam
import com.vlad411.notify2tv.service.OverlayState

@Composable
fun TvMainScreen(
    modifier: Modifier = Modifier,
    onSwitchToMobile: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val receiverManager = remember { TvReceiverManager.getInstance(context) }

    val serverState by receiverManager.serverState.collectAsState()
    val pinCode by receiverManager.pinCode.collectAsState()
    val pairedDevices by receiverManager.pairedDevices.collectAsState()
    val isNsdRegistered by receiverManager.isNsdRegistered.collectAsState()
    val overlayStateFromManager by receiverManager.overlayState.collectAsState()
    val connectedCount by receiverManager.connectedClientsCount.collectAsState()
    val bannerPosition by receiverManager.bannerPosition.collectAsState()
    val bannerTransparencyPercent by receiverManager.bannerTransparencyPercent.collectAsState()
    val bannerTimeoutSeconds by receiverManager.bannerTimeoutSeconds.collectAsState()
    val isSystemOverlayEnabled by receiverManager.isSystemOverlayEnabled.collectAsState()
    val isExpandedCameraBannerEnabled by receiverManager.isExpandedCameraBannerEnabled.collectAsState()

    var localIp by remember { mutableStateOf("0.0.0.0") }
    var qrBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var hasOverlayPermission by remember {
        mutableStateOf(runCatching { Settings.canDrawOverlays(context) }.getOrDefault(false))
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME || event == Lifecycle.Event.ON_START) {
                receiverManager.setAppInForeground(true)
                hasOverlayPermission = runCatching { Settings.canDrawOverlays(context) }.getOrDefault(false)
            } else if (event == Lifecycle.Event.ON_STOP) {
                receiverManager.setAppInForeground(false)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            receiverManager.setAppInForeground(false)
        }
    }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val ip = runCatching { NetworkUtils.getLocalIpAddress() }.getOrNull() ?: "0.0.0.0"
            withContext(Dispatchers.Main) {
                localIp = ip
            }
        }
        hasOverlayPermission = runCatching { Settings.canDrawOverlays(context) }.getOrDefault(false)
        if (serverState !is ServerState.Running) {
            runCatching { TvServerService.startService(context) }
        }
    }

    val isServerRunning = serverState is ServerState.Running

    // Generated QR Code payload string asynchronously on IO thread
    val qrPayload = "notify2tv://pair?ip=$localIp&port=${NetworkUtils.DEFAULT_PORT}&pin=$pinCode"
    LaunchedEffect(qrPayload) {
        withContext(Dispatchers.IO) {
            val bmp = runCatching {
                QrCodeGenerator.generateQrCodeBitmap(qrPayload, size = 320)
            }.getOrNull()
            withContext(Dispatchers.Main) {
                qrBitmap = bmp
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            // Header Bar
            TvHeaderSection(
                localIp = localIp,
                isServerRunning = isServerRunning,
                isNsdRegistered = isNsdRegistered,
                connectedCount = connectedCount,
                onToggleServer = {
                    if (isServerRunning) {
                        TvServerService.stopService(context)
                    } else {
                        TvServerService.startService(context)
                    }
                },
                onSwitchToMobile = onSwitchToMobile
            )

            if (!hasOverlayPermission) {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Warning,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "⚠️ OVERLAY PERMISSION REQUIRED: To show notifications over Netflix, YouTube, and other TV apps, click below to enable 'Display over other apps'.",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Button(
                            onClick = {
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                                context.startActivity(intent)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error
                            )
                        ) {
                            Text("Grant Permission", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Main Content Row (Left: Pairing & QR Code, Right: Devices, Test Controls, Permission)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Left Column: Pairing PIN & QR Code
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    TvPairingCard(
                        pinCode = pinCode,
                        qrBitmap = qrBitmap,
                        onRegeneratePin = { receiverManager.generateNewPin() }
                    )
                }

                // Right Column: Permission, Settings, Connected Devices & Test Controls
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    TvSystemOverlaySettingCard(
                        isSystemOverlayEnabled = isSystemOverlayEnabled,
                        onToggleSystemOverlay = { enabled ->
                            receiverManager.setSystemOverlayEnabled(enabled)
                        },
                        hasOverlayPermission = hasOverlayPermission,
                        onGrantPermission = {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                        }
                    )

                    TvCameraBannerSettingCard(
                        isExpandedCameraBannerEnabled = isExpandedCameraBannerEnabled,
                        onToggleExpandedCameraBanner = { enabled ->
                            receiverManager.setExpandedCameraBannerEnabled(enabled)
                        }
                    )

                    TvBannerPositionCard(
                        currentPosition = bannerPosition,
                        onPositionSelected = { position ->
                            receiverManager.setBannerPosition(position)
                        }
                    )

                    TvBannerTransparencyCard(
                        currentTransparencyPercent = bannerTransparencyPercent,
                        onTransparencySelected = { percent ->
                            receiverManager.setBannerTransparencyPercent(percent)
                        }
                    )

                    TvBannerTimeoutCard(
                        currentTimeoutSeconds = bannerTimeoutSeconds,
                        onTimeoutSelected = { seconds ->
                            receiverManager.setBannerTimeoutSeconds(seconds)
                        }
                    )

                    TvConnectedDevicesCard(
                        pairedDevices = pairedDevices,
                        onUnpair = { deviceId -> receiverManager.unpairDevice(deviceId) }
                    )

                    TvLiveTestingCard(
                        onTestNotification = {
                            receiverManager.showTestNotificationOverlay()
                        },
                        onTestCall = {
                            receiverManager.showTestCallOverlay()
                        },
                        onTestCameraNotification = {
                            receiverManager.triggerTestCameraNotification()
                        },
                        onTestBackgroundOverlay = {
                            Toast.makeText(
                                context,
                                "Overlay arriving in 5 seconds! Press Home or open Netflix now...",
                                Toast.LENGTH_LONG
                            ).show()
                            coroutineScope.launch {
                                delay(5000L)
                                receiverManager.triggerTestNotification()
                            }
                        }
                    )
                }
            }
        }

        // In-App Overlay Banner Display
        if (overlayStateFromManager != null) {
            val overlayWidth = if (overlayStateFromManager is OverlayState.LargeImageOverlay) 620.dp else 420.dp
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .zIndex(9999f),
                contentAlignment = bannerPosition.alignment
            ) {
                TvOverlayBanner(
                    overlayState = overlayStateFromManager,
                    bannerPosition = bannerPosition,
                    timeoutSeconds = bannerTimeoutSeconds,
                    transparencyPercent = bannerTransparencyPercent,
                    modifier = Modifier
                        .wrapContentSize()
                        .width(overlayWidth),
                    onDismiss = {
                        receiverManager.dismissOverlay()
                    },
                    onActionClicked = { actionId, notificationId ->
                        receiverManager.sendNotificationAction(actionId, notificationId)
                    }
                )
            }
        }
    }
}

@Composable
private fun TvHeaderSection(
    localIp: String,
    isServerRunning: Boolean,
    isNsdRegistered: Boolean,
    connectedCount: Int,
    onToggleServer: () -> Unit,
    onSwitchToMobile: (() -> Unit)? = null
) {
    var isToggleBtnFocused by remember { mutableStateOf(false) }
    var isSwitchBtnFocused by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        tonalElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Rounded.Tv,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(36.dp)
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Notify2TV Receiver",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "IP Address: $localIp:${NetworkUtils.DEFAULT_PORT}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    if (isNsdRegistered) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = CircleShape
                        ) {
                            Text(
                                text = "NSD Published (_notify2tv)",
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }

            // Server Status Badge
            Surface(
                color = if (isServerRunning) Color(0xFF2E7D32) else Color(0xFFC62828),
                shape = CircleShape,
                modifier = Modifier.padding(end = 16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isServerRunning) "Active & Listening ($connectedCount Clients)" else "Stopped",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            // Start/Stop Toggle Button
            Button(
                onClick = onToggleServer,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isServerRunning) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier
                    .onFocusChanged { isToggleBtnFocused = it.isFocused }
                    .border(
                        width = if (isToggleBtnFocused) 3.dp else 0.dp,
                        color = if (isToggleBtnFocused) MaterialTheme.colorScheme.tertiary else Color.Transparent,
                        shape = RoundedCornerShape(24.dp)
                    )
                    .focusable()
            ) {
                Icon(
                    imageVector = if (isServerRunning) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                    contentDescription = null
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = if (isServerRunning) "Stop TV Server" else "Start TV Server")
            }

            if (onSwitchToMobile != null) {
                Spacer(modifier = Modifier.width(12.dp))
                OutlinedButton(
                    onClick = onSwitchToMobile,
                    modifier = Modifier
                        .onFocusChanged { isSwitchBtnFocused = it.isFocused }
                        .border(
                            width = if (isSwitchBtnFocused) 3.dp else 0.dp,
                            color = if (isSwitchBtnFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                            shape = RoundedCornerShape(24.dp)
                        )
                        .focusable(),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PhoneAndroid,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Switch to Mobile Companion Mode")
                }
            }
        }
    }
}

@Composable
private fun TvPairingCard(
    pinCode: String,
    qrBitmap: Bitmap?,
    onRegeneratePin: () -> Unit
) {
    var isBtnFocused by remember { mutableStateOf(false) }
    var isCardFocused by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxSize()
            .onFocusChanged { isCardFocused = it.isFocused }
            .border(
                width = if (isCardFocused) 2.dp else 0.dp,
                color = if (isCardFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                shape = RoundedCornerShape(20.dp)
            )
            .focusable(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.Lock,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Mobile Pairing Info",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // PIN Code Display
            Text(
                text = "PAIRING PIN CODE",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Formatted 6-digit PIN e.g. "8 4 9 2 0 1"
            val formattedPin = pinCode.chunked(1).joinToString("   ")
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = formattedPin,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onRegeneratePin,
                modifier = Modifier
                    .onFocusChanged { isBtnFocused = it.isFocused }
                    .border(
                        width = if (isBtnFocused) 3.dp else 0.dp,
                        color = if (isBtnFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .focusable()
            ) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "Regenerate PIN", fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(modifier = Modifier.height(16.dp))

            // QR Code Section
            Text(
                text = "SCAN QR CODE WITH MOBILE APP",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (qrBitmap != null) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White,
                    shadowElevation = 8.dp,
                    modifier = Modifier.padding(4.dp)
                ) {
                    Image(
                        bitmap = qrBitmap.asImageBitmap(),
                        contentDescription = "Pairing QR Code",
                        modifier = Modifier
                            .size(190.dp)
                            .padding(12.dp)
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .size(190.dp)
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(16.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.QrCode2,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Open Notify2TV on phone -> Scan QR Code to connect automatically",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun TvConnectedDevicesCard(
    pairedDevices: List<PairedDeviceInfo>,
    onUnpair: (deviceId: String) -> Unit
) {
    var isCardFocused by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { isCardFocused = it.isFocused }
            .border(
                width = if (isCardFocused) 2.dp else 0.dp,
                color = if (isCardFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                shape = RoundedCornerShape(20.dp)
            )
            .focusable(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.CellTower,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Connected Mobile Devices (${pairedDevices.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (pairedDevices.isEmpty()) {
                Text(
                    text = "No mobile devices paired yet. Scan the QR code or enter PIN from mobile app.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.height(140.dp)
                ) {
                    items(pairedDevices) { device ->
                        PairedDeviceItem(
                            device = device,
                            onUnpair = { onUnpair(device.deviceId) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PairedDeviceItem(
    device: PairedDeviceInfo,
    onUnpair: () -> Unit
) {
    var isItemFocused by remember { mutableStateOf(false) }
    var isUnpairFocused by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isItemFocused) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer,
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { isItemFocused = it.isFocused }
            .border(
                width = if (isItemFocused || isUnpairFocused) 2.dp else 0.dp,
                color = if (isUnpairFocused) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                shape = RoundedCornerShape(12.dp)
            )
            .focusable()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Rounded.CheckCircle,
                contentDescription = null,
                tint = Color(0xFF2E7D32),
                modifier = Modifier.size(20.dp)
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = device.deviceName,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "IP: ${device.ip}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            IconButton(
                onClick = onUnpair,
                modifier = Modifier
                    .onFocusChanged { isUnpairFocused = it.isFocused }
                    .border(
                        width = if (isUnpairFocused) 2.dp else 0.dp,
                        color = if (isUnpairFocused) MaterialTheme.colorScheme.error else Color.Transparent,
                        shape = CircleShape
                    )
                    .focusable()
            ) {
                Icon(
                    imageVector = Icons.Rounded.Delete,
                    contentDescription = "Unpair",
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun TvLiveTestingCard(
    onTestNotification: () -> Unit,
    onTestCall: () -> Unit,
    onTestCameraNotification: () -> Unit,
    onTestBackgroundOverlay: () -> Unit
) {
    var isNotifBtnFocused by remember { mutableStateOf(false) }
    var isCallBtnFocused by remember { mutableStateOf(false) }
    var isCamBtnFocused by remember { mutableStateOf(false) }
    var isBgTestBtnFocused by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "Live TV Overlay Tester",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Simulate incoming alerts to verify TV overlay banners and D-pad interaction:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onTestNotification,
                    modifier = Modifier
                        .weight(1f)
                        .onFocusChanged { isNotifBtnFocused = it.isFocused }
                        .border(
                            width = if (isNotifBtnFocused) 3.dp else 0.dp,
                            color = if (isNotifBtnFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                            shape = RoundedCornerShape(24.dp)
                        )
                        .focusable(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Notifications,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Test Notification", fontSize = 13.sp)
                }

                Button(
                    onClick = onTestCall,
                    modifier = Modifier
                        .weight(1f)
                        .onFocusChanged { isCallBtnFocused = it.isFocused }
                        .border(
                            width = if (isCallBtnFocused) 3.dp else 0.dp,
                            color = if (isCallBtnFocused) MaterialTheme.colorScheme.secondary else Color.Transparent,
                            shape = RoundedCornerShape(24.dp)
                        )
                        .focusable(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Call,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Test Call Alert", fontSize = 13.sp)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onTestCameraNotification,
                modifier = Modifier
                    .fillMaxWidth()
                    .onFocusChanged { isCamBtnFocused = it.isFocused }
                    .border(
                        width = if (isCamBtnFocused) 3.dp else 0.dp,
                        color = if (isCamBtnFocused) Color(0xFFFF5252) else Color.Transparent,
                        shape = RoundedCornerShape(24.dp)
                    )
                    .focusable(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF3E1212),
                    contentColor = Color(0xFFFF8A80)
                )
            ) {
                Icon(
                    imageVector = Icons.Rounded.Videocam,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Test Security Camera Alert", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onTestBackgroundOverlay,
                modifier = Modifier
                    .fillMaxWidth()
                    .onFocusChanged { isBgTestBtnFocused = it.isFocused }
                    .border(
                        width = if (isBgTestBtnFocused) 3.dp else 0.dp,
                        color = if (isBgTestBtnFocused) MaterialTheme.colorScheme.tertiary else Color.Transparent,
                        shape = RoundedCornerShape(24.dp)
                    )
                    .focusable(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                    contentColor = MaterialTheme.colorScheme.onTertiaryContainer
                )
            ) {
                Icon(
                    imageVector = Icons.Rounded.Tv,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Test Background Overlay (Minimize & Test)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun TvCameraBannerSettingCard(
    isExpandedCameraBannerEnabled: Boolean,
    onToggleExpandedCameraBanner: (Boolean) -> Unit
) {
    var isCardFocused by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { isCardFocused = it.isFocused }
            .border(
                width = if (isCardFocused) 2.dp else 0.dp,
                color = if (isCardFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                shape = RoundedCornerShape(20.dp)
            )
            .focusable(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Large Security Camera Image Banner",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Show expanded full-screen image banner after camera notifications",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Switch(
                    checked = isExpandedCameraBannerEnabled,
                    onCheckedChange = onToggleExpandedCameraBanner
                )
            }
        }
    }
}

@Composable
private fun TvSystemOverlaySettingCard(
    isSystemOverlayEnabled: Boolean,
    onToggleSystemOverlay: (Boolean) -> Unit,
    hasOverlayPermission: Boolean,
    onGrantPermission: () -> Unit
) {
    var isCardFocused by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { isCardFocused = it.isFocused }
            .border(
                width = if (isCardFocused) 2.dp else 0.dp,
                color = if (isCardFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                shape = RoundedCornerShape(20.dp)
            )
            .focusable(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "System Overlay Window",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Show over other TV apps when in background",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Switch(
                    checked = isSystemOverlayEnabled,
                    onCheckedChange = onToggleSystemOverlay
                )
            }

            if (isSystemOverlayEnabled && !hasOverlayPermission) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Permission required to display over other apps.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = onGrantPermission,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error
                        )
                    ) {
                        Text("Grant Permission", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TvBannerPositionCard(
    currentPosition: BannerPosition,
    onPositionSelected: (BannerPosition) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "TV Banner Position",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Select screen corner for overlay notification banners on TV:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BannerPosition.entries.forEach { position ->
                    val isSelected = position == currentPosition
                    var isFocused by remember { mutableStateOf(false) }

                    FilterChip(
                        selected = isSelected,
                        onClick = { onPositionSelected(position) },
                        label = {
                            Text(
                                text = position.displayName,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        leadingIcon = if (isSelected) {
                            {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        } else null,
                        modifier = Modifier
                            .weight(1f)
                            .onFocusChanged { isFocused = it.isFocused }
                            .border(
                                width = if (isFocused) 3.dp else 0.dp,
                                color = if (isFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .focusable()
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TvBannerTransparencyCard(
    currentTransparencyPercent: Int,
    onTransparencySelected: (Int) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TV Banner Transparency",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "$currentTransparencyPercent%",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Set opacity level for overlay notification banners on TV (0% = opaque, 100% = transparent):",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                var isMinusFocused by remember { mutableStateOf(false) }
                OutlinedButton(
                    onClick = {
                        val newPct = (currentTransparencyPercent - 10).coerceIn(0, 100)
                        onTransparencySelected(newPct)
                    },
                    enabled = currentTransparencyPercent > 0,
                    modifier = Modifier
                        .onFocusChanged { isMinusFocused = it.isFocused }
                        .border(
                            width = if (isMinusFocused) 3.dp else 0.dp,
                            color = if (isMinusFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .focusable(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("-10%", fontWeight = FontWeight.Bold)
                }

                Slider(
                    value = currentTransparencyPercent.toFloat(),
                    onValueChange = { newValue ->
                        val rounded = (newValue / 10f).roundToInt() * 10
                        onTransparencySelected(rounded.coerceIn(0, 100))
                    },
                    valueRange = 0f..100f,
                    steps = 9,
                    modifier = Modifier.weight(1f)
                )

                var isPlusFocused by remember { mutableStateOf(false) }
                OutlinedButton(
                    onClick = {
                        val newPct = (currentTransparencyPercent + 10).coerceIn(0, 100)
                        onTransparencySelected(newPct)
                    },
                    enabled = currentTransparencyPercent < 100,
                    modifier = Modifier
                        .onFocusChanged { isPlusFocused = it.isFocused }
                        .border(
                            width = if (isPlusFocused) 3.dp else 0.dp,
                            color = if (isPlusFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .focusable(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("+10%", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(0, 10, 20, 30, 50, 70, 100).forEach { preset ->
                    val isSelected = preset == currentTransparencyPercent
                    var isFocused by remember { mutableStateOf(false) }

                    FilterChip(
                        selected = isSelected,
                        onClick = { onTransparencySelected(preset) },
                        label = {
                            Text(
                                text = "$preset%",
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        leadingIcon = if (isSelected) {
                            {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        } else null,
                        modifier = Modifier
                            .weight(1f)
                            .onFocusChanged { isFocused = it.isFocused }
                            .border(
                                width = if (isFocused) 3.dp else 0.dp,
                                color = if (isFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .focusable()
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TvBannerTimeoutCard(
    currentTimeoutSeconds: Int,
    onTimeoutSelected: (Int) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "Auto-Dismiss Timeout: $currentTimeoutSeconds Seconds",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Select how long notification banners stay on screen before auto-dismissing:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(3, 5, 7, 10).forEach { seconds ->
                    val isSelected = seconds == currentTimeoutSeconds
                    var isFocused by remember { mutableStateOf(false) }

                    FilterChip(
                        selected = isSelected,
                        onClick = { onTimeoutSelected(seconds) },
                        label = {
                            Text(
                                text = "$seconds Seconds",
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        leadingIcon = if (isSelected) {
                            {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        } else null,
                        modifier = Modifier
                            .weight(1f)
                            .onFocusChanged { isFocused = it.isFocused }
                            .border(
                                width = if (isFocused) 3.dp else 0.dp,
                                color = if (isFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .focusable()
                    )
                }
            }
        }
    }
}
