package com.vlad411.notify2tv.util

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class NsdPublisher(context: Context) {

    private val nsdManager = runCatching {
        context.applicationContext.getSystemService(Context.NSD_SERVICE) as? NsdManager
    }.getOrNull()

    private val _isRegistered = MutableStateFlow(false)
    val isRegistered: StateFlow<Boolean> = _isRegistered.asStateFlow()

    private var registrationListener: NsdManager.RegistrationListener? = null
    private var registeredServiceName: String? = null

    companion object {
        private const val TAG = "NsdPublisher"
        const val SERVICE_TYPE = "_notify2tv._tcp"
        const val DEFAULT_SERVICE_NAME = "Notify2TV-Receiver"
    }

    fun registerService(port: Int, customName: String = DEFAULT_SERVICE_NAME) {
        if (_isRegistered.value || nsdManager == null) return

        val serviceInfo = NsdServiceInfo().apply {
            serviceName = customName
            serviceType = SERVICE_TYPE
            this.port = port
        }

        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(serviceInfo: NsdServiceInfo) {
                registeredServiceName = serviceInfo.serviceName
                _isRegistered.value = true
                Log.d(TAG, "NSD Service registered successfully as: ${serviceInfo.serviceName}")
            }

            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                Log.e(TAG, "NSD Service registration failed with error: $errorCode")
                _isRegistered.value = false
            }

            override fun onServiceUnregistered(arg0: NsdServiceInfo) {
                Log.d(TAG, "NSD Service unregistered successfully: ${arg0.serviceName}")
                _isRegistered.value = false
            }

            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                Log.e(TAG, "NSD Service unregistration failed with error: $errorCode")
                _isRegistered.value = false
            }
        }

        registrationListener = listener
        runCatching {
            nsdManager?.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, listener)
        }.onFailure {
            Log.e(TAG, "Failed to call registerService", it)
            _isRegistered.value = false
        }
    }

    fun unregisterService() {
        val listener = registrationListener ?: return
        runCatching {
            nsdManager?.unregisterService(listener)
        }.onFailure {
            Log.e(TAG, "Failed to unregister NSD service", it)
        }
        registrationListener = null
        registeredServiceName = null
        _isRegistered.value = false
    }
}
