package com.vlad411.notify2tv.network

import com.vlad411.notify2tv.model.NetworkMessage
import io.ktor.client.HttpClient
import io.ktor.client.engine.cio.CIO
import io.ktor.client.plugins.websocket.DefaultClientWebSocketSession
import io.ktor.client.plugins.websocket.WebSockets
import io.ktor.client.plugins.websocket.webSocket
import io.ktor.websocket.CloseReason
import io.ktor.websocket.Frame
import io.ktor.websocket.close
import io.ktor.websocket.readText
import io.ktor.websocket.send
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.time.Duration.Companion.seconds

sealed interface ClientConnectionState {
    object Disconnected : ClientConnectionState
    object Connecting : ClientConnectionState
    data class Connected(val hostIp: String, val port: Int) : ClientConnectionState
    data class Error(val message: String) : ClientConnectionState
}

class MobileWebSocketClient {
    private var client: HttpClient? = null
    private var webSocketSession: DefaultClientWebSocketSession? = null

    private val _connectionState = MutableStateFlow<ClientConnectionState>(ClientConnectionState.Disconnected)
    val connectionState: StateFlow<ClientConnectionState> = _connectionState.asStateFlow()

    private val _incomingMessages = MutableSharedFlow<NetworkMessage>(extraBufferCapacity = 64)
    val incomingMessages: SharedFlow<NetworkMessage> = _incomingMessages.asSharedFlow()

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var connectionJob: Job? = null

    fun connect(hostIp: String, port: Int = NetworkUtils.DEFAULT_PORT) {
        if (_connectionState.value is ClientConnectionState.Connected || _connectionState.value is ClientConnectionState.Connecting) {
            return
        }

        _connectionState.value = ClientConnectionState.Connecting

        connectionJob = scope.launch {
            try {
                val httpClient = HttpClient(CIO) {
                    install(WebSockets) {
                        pingIntervalMillis = 15000
                    }
                }
                client = httpClient

                httpClient.webSocket(host = hostIp, port = port, path = NetworkUtils.WS_PATH) {
                    webSocketSession = this
                    _connectionState.value = ClientConnectionState.Connected(hostIp, port)

                    for (frame in incoming) {
                        if (frame is Frame.Text) {
                            val text = frame.readText()
                            val message = NetworkMessage.fromJson(text)
                            if (message != null) {
                                _incomingMessages.emit(message)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                _connectionState.value = ClientConnectionState.Error(e.localizedMessage ?: "Connection failed")
            } finally {
                webSocketSession = null
                if (_connectionState.value is ClientConnectionState.Connected) {
                    _connectionState.value = ClientConnectionState.Disconnected
                }
            }
        }
    }

    suspend fun sendMessage(message: NetworkMessage): Boolean {
        val session = webSocketSession ?: return false
        return runCatching {
            session.send(Frame.Text(message.toJson()))
            true
        }.getOrDefault(false)
    }

    fun disconnect() {
        scope.launch {
            runCatching {
                webSocketSession?.close(CloseReason(CloseReason.Codes.NORMAL, "User disconnected"))
                client?.close()
            }
            connectionJob?.cancel()
            webSocketSession = null
            client = null
            _connectionState.value = ClientConnectionState.Disconnected
        }
    }
}
