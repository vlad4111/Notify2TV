package com.vlad411.notify2tv.util

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class DiscoveredTvDevice(
    val name: String,
    val ip: String,
    val port: Int
)

class NsdDiscoveryManager(context: Context) {

    private val nsdManager = runCatching {
        context.applicationContext.getSystemService(Context.NSD_SERVICE) as? NsdManager
    }.getOrNull()

    private val _discoveredDevices = MutableStateFlow<List<DiscoveredTvDevice>>(emptyList())
    val discoveredDevices: StateFlow<List<DiscoveredTvDevice>> = _discoveredDevices.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private var discoveryListener: NsdManager.DiscoveryListener? = null

    companion object {
        private const val TAG = "NsdDiscoveryManager"
        const val SERVICE_TYPE = "_notify2tv._tcp."
    }

    fun startDiscovery() {
        if (_isSearching.value || nsdManager == null) return

        _discoveredDevices.value = emptyList()
        _isSearching.value = true

        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(regType: String) {
                Log.d(TAG, "Service discovery started: $regType")
            }

            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                Log.d(TAG, "Service found: ${serviceInfo.serviceName}")
                if (serviceInfo.serviceType.contains("notify2tv") || serviceInfo.serviceName.contains("Notify2TV", ignoreCase = true)) {
                    resolveService(serviceInfo)
                }
            }

            override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                Log.d(TAG, "Service lost: ${serviceInfo.serviceName}")
                _discoveredDevices.value = _discoveredDevices.value.filter { it.name != serviceInfo.serviceName }
            }

            override fun onDiscoveryStopped(serviceType: String) {
                Log.d(TAG, "Discovery stopped: $serviceType")
                _isSearching.value = false
            }

            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                Log.e(TAG, "Discovery start failed: $errorCode")
                _isSearching.value = false
                stopDiscovery()
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                Log.e(TAG, "Discovery stop failed: $errorCode")
                _isSearching.value = false
            }
        }

        discoveryListener = listener
        runCatching {
            nsdManager?.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
        }.onFailure { e ->
            Log.e(TAG, "Failed to start service discovery", e)
            _isSearching.value = false
        }
    }

    private fun resolveService(serviceInfo: NsdServiceInfo) {
        val resolveListener = object : NsdManager.ResolveListener {
            override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                Log.e(TAG, "Resolve failed: $errorCode")
            }

            override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                val hostIp = serviceInfo.host?.hostAddress ?: return
                val device = DiscoveredTvDevice(
                    name = serviceInfo.serviceName,
                    ip = hostIp,
                    port = serviceInfo.port
                )

                val current = _discoveredDevices.value.toMutableList()
                if (current.none { it.ip == device.ip && it.port == device.port }) {
                    current.add(device)
                    _discoveredDevices.value = current
                }
            }
        }

        runCatching {
            nsdManager?.resolveService(serviceInfo, resolveListener)
        }.onFailure { e ->
            Log.e(TAG, "Failed to resolve service", e)
        }
    }

    fun stopDiscovery() {
        val listener = discoveryListener ?: return
        runCatching {
            nsdManager?.stopServiceDiscovery(listener)
        }.onFailure { e ->
            Log.e(TAG, "Failed to stop service discovery", e)
        }
        discoveryListener = null
        _isSearching.value = false
    }
}
