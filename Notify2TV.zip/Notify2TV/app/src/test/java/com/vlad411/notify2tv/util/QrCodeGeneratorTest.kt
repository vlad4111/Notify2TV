package com.vlad411.notify2tv.util

import org.junit.Assert.assertTrue
import org.junit.Test

class QrCodeGeneratorTest {

    @Test
    fun testQrCodeGeneratorPayloadNotEmpty() {
        val payload = "notify2tv://192.168.1.100:8080?pin=123456"
        assertTrue(payload.startsWith("notify2tv://"))
    }
}
