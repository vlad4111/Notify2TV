package com.vlad411.notify2tv.model

import android.view.Gravity
import androidx.compose.ui.Alignment
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NetworkMessageTest {

    @Test
    fun testNotificationPayloadSerialization() {
        val notification = NotificationPayload(
            id = "notif-123",
            appName = "WhatsApp",
            packageName = "com.whatsapp",
            title = "John Doe",
            body = "Hey, are we still meeting today?",
            timestamp = 1700000000000L,
            appIconBase64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
            actions = listOf(
                NotificationActionPayload(actionId = "reply", title = "Reply", isQuickReply = true)
            )
        )

        val message: NetworkMessage = NetworkMessage.Notification(payload = notification)
        val json = message.toJson()

        assertNotNull(json)
        val decoded = NetworkMessage.fromJson(json) as? NetworkMessage.Notification
        assertNotNull(decoded)
        assertEquals("notif-123", decoded?.payload?.id)
        assertEquals("WhatsApp", decoded?.payload?.appName)
        assertEquals("com.whatsapp", decoded?.payload?.packageName)
        assertEquals(1, decoded?.payload?.actions?.size)
        assertEquals("reply", decoded?.payload?.actions?.first()?.actionId)
    }

    @Test
    fun testCallPayloadSerialization() {
        val call = CallPayload(
            id = "call-456",
            callType = CallType.INCOMING,
            callerName = "Alice",
            callerNumber = "+1234567890"
        )

        val message: NetworkMessage = NetworkMessage.Call(payload = call)
        val json = message.toJson()

        val decoded = NetworkMessage.fromJson(json) as? NetworkMessage.Call
        assertNotNull(decoded)
        assertEquals("call-456", decoded?.payload?.id)
        assertEquals(CallType.INCOMING, decoded?.payload?.callType)
        assertEquals("Alice", decoded?.payload?.callerName)
        assertEquals("+1234567890", decoded?.payload?.callerNumber)
    }

    @Test
    fun testPairingPayloadSerialization() {
        val pairing = PairingPayload(
            pairingCode = "123456",
            ip = "192.168.1.50",
            port = 8080,
            deviceId = "device-abc",
            deviceName = "Living Room TV",
            clientType = ClientType.TV,
            status = PairingStatus.PENDING
        )

        val request: NetworkMessage = NetworkMessage.PairingRequest(payload = pairing)
        val jsonRequest = request.toJson()

        val decodedRequest = NetworkMessage.fromJson(jsonRequest) as? NetworkMessage.PairingRequest
        assertNotNull(decodedRequest)
        assertEquals("123456", decodedRequest?.payload?.pairingCode)
        assertEquals(ClientType.TV, decodedRequest?.payload?.clientType)

        val response: NetworkMessage = NetworkMessage.PairingResponse(
            payload = pairing.copy(status = PairingStatus.ACCEPTED),
            accepted = true,
            message = "Pairing successful"
        )
        val jsonResponse = response.toJson()

        val decodedResponse = NetworkMessage.fromJson(jsonResponse) as? NetworkMessage.PairingResponse
        assertNotNull(decodedResponse)
        assertTrue(decodedResponse?.accepted == true)
        assertEquals("Pairing successful", decodedResponse?.message)
    }

    @Test
    fun testBannerPositionEnum() {
        assertEquals("Top Left", BannerPosition.TOP_LEFT.displayName)
        assertEquals("Top Right", BannerPosition.TOP_RIGHT.displayName)
        assertEquals("Bottom Left", BannerPosition.BOTTOM_LEFT.displayName)
        assertEquals("Bottom Right", BannerPosition.BOTTOM_RIGHT.displayName)

        assertEquals(Alignment.TopStart, BannerPosition.TOP_LEFT.alignment)
        assertEquals(Alignment.TopEnd, BannerPosition.TOP_RIGHT.alignment)
        assertEquals(Alignment.BottomStart, BannerPosition.BOTTOM_LEFT.alignment)
        assertEquals(Alignment.BottomEnd, BannerPosition.BOTTOM_RIGHT.alignment)

        assertEquals(Gravity.TOP or Gravity.START, BannerPosition.TOP_LEFT.gravity)
        assertEquals(Gravity.TOP or Gravity.END, BannerPosition.TOP_RIGHT.gravity)
        assertEquals(Gravity.BOTTOM or Gravity.START, BannerPosition.BOTTOM_LEFT.gravity)
        assertEquals(Gravity.BOTTOM or Gravity.END, BannerPosition.BOTTOM_RIGHT.gravity)
    }

    @Test
    fun testBannerPositionUpdateSerialization() {
        val message: NetworkMessage = NetworkMessage.BannerPositionUpdate(position = BannerPosition.BOTTOM_LEFT.name)
        val json = message.toJson()

        val decoded = NetworkMessage.fromJson(json) as? NetworkMessage.BannerPositionUpdate
        assertNotNull(decoded)
        assertEquals("BOTTOM_LEFT", decoded?.position)
    }

    @Test
    fun testBannerTransparencyUpdateSerialization() {
        val message: NetworkMessage = NetworkMessage.BannerTransparencyUpdate(percent = 40)
        val json = message.toJson()

        val decoded = NetworkMessage.fromJson(json) as? NetworkMessage.BannerTransparencyUpdate
        assertNotNull(decoded)
        assertEquals(40, decoded?.percent)
    }

    @Test
    fun testBannerTimeoutUpdateSerialization() {
        val message: NetworkMessage = NetworkMessage.BannerTimeoutUpdate(seconds = 5)
        val json = message.toJson()

        val decoded = NetworkMessage.fromJson(json) as? NetworkMessage.BannerTimeoutUpdate
        assertNotNull(decoded)
        assertEquals(5, decoded?.seconds)
    }
}
