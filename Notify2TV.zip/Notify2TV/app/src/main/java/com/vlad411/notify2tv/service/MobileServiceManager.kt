package com.vlad411.notify2tv.service

import android.content.Context
import android.os.Build
import android.util.Log
import com.vlad411.notify2tv.model.BannerPosition
import com.vlad411.notify2tv.model.CallPayload
import com.vlad411.notify2tv.model.ClientType
import com.vlad411.notify2tv.model.NetworkMessage
import com.vlad411.notify2tv.model.NotificationPayload
import com.vlad411.notify2tv.model.PairingPayload
import com.vlad411.notify2tv.model.PairingStatus
import com.vlad411.notify2tv.network.ClientConnectionState
import com.vlad411.notify2tv.network.MobileWebSocketClient
import com.vlad411.notify2tv.network.NetworkUtils
import androidx.core.app.NotificationManagerCompat
import com.vlad411.notify2tv.util.CameraNotificationDetector
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

enum class LogType {
    NOTIFICATION,
    CALL,
    PAIRING,
    SYSTEM
}

enum class LogStatus {
    SENT,
    RECEIVED,
    FAILED,
    INFO
}

data class ForwardingLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val type: LogType,
    val title: String,
    val description: String,
    val status: LogStatus
)

class MobileServiceManager private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val prefs = runCatching {
        appContext.getSharedPreferences("notify2tv_mobile_prefs", Context.MODE_PRIVATE)
    }.getOrNull()

    val client = MobileWebSocketClient()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _tvIp = MutableStateFlow(prefs?.getString("tv_ip", "") ?: "")
    val tvIp: StateFlow<String> = _tvIp.asStateFlow()

    private val _tvPort = MutableStateFlow(prefs?.getInt("tv_port", NetworkUtils.DEFAULT_PORT) ?: NetworkUtils.DEFAULT_PORT)
    val tvPort: StateFlow<Int> = _tvPort.asStateFlow()

    private val _tvPin = MutableStateFlow(prefs?.getString("tv_pin", "") ?: "")
    val tvPin: StateFlow<String> = _tvPin.asStateFlow()

    private val _isForwardingEnabled = MutableStateFlow(prefs?.getBoolean("forwarding_enabled", true) ?: true)
    val isForwardingEnabled: StateFlow<Boolean> = _isForwardingEnabled.asStateFlow()

    private val _isIgnorePersistentEnabled = MutableStateFlow(
        prefs?.getBoolean("ignore_persistent_notifications", true) ?: true
    )
    val isIgnorePersistentEnabled: StateFlow<Boolean> = _isIgnorePersistentEnabled.asStateFlow()

    private val _isExpandedCameraBannerEnabled = MutableStateFlow(
        prefs?.getBoolean("expanded_camera_banner_enabled", true) ?: true
    )
    val isExpandedCameraBannerEnabled: StateFlow<Boolean> = _isExpandedCameraBannerEnabled.asStateFlow()

    private val _bannerTransparencyPercent = MutableStateFlow(
        prefs?.getInt("banner_transparency_percent", 0)?.coerceIn(0, 100) ?: 0
    )
    val bannerTransparencyPercent: StateFlow<Int> = _bannerTransparencyPercent.asStateFlow()

    private val _bannerTimeoutSeconds = MutableStateFlow(
        prefs?.getInt("banner_timeout_seconds", 7)?.let { if (it in listOf(3, 5, 7, 10)) it else 7 } ?: 7
    )
    val bannerTimeoutSeconds: StateFlow<Int> = _bannerTimeoutSeconds.asStateFlow()

    private val _pairingStatus = MutableStateFlow(
        runCatching {
            val statusStr = prefs?.getString("pairing_status", PairingStatus.PENDING.name) ?: PairingStatus.PENDING.name
            PairingStatus.valueOf(statusStr)
        }.getOrDefault(PairingStatus.PENDING)
    )
    val pairingStatus: StateFlow<PairingStatus> = _pairingStatus.asStateFlow()

    private val _logs = MutableStateFlow<List<ForwardingLogEntry>>(emptyList())
    val logs: StateFlow<List<ForwardingLogEntry>> = _logs.asStateFlow()

    private val _pairingMessage = MutableStateFlow<String?>(null)
    val pairingMessage: StateFlow<String?> = _pairingMessage.asStateFlow()

    var actionHandler: ((NetworkMessage.Action) -> Unit)? = null

    init {
        checkNotificationListenerPermission()

        // Automatic Connection on App Launch if paired TV IP is saved
        if (_tvIp.value.isNotBlank()) {
            connectAndPair(_tvIp.value, _tvPort.value, _tvPin.value)
        }

        scope.launch {
            runCatching {
                client.incomingMessages.collect { message ->
                    handleIncomingMessage(message)
                }
            }.onFailure { e ->
                Log.e("MobileServiceManager", "Error in incoming message collector: ${e.localizedMessage}", e)
            }
        }

        scope.launch {
            runCatching {
                client.connectionState.collect { state ->
                    when (state) {
                        is ClientConnectionState.Connected -> {
                            addLog(LogType.SYSTEM, "Connected to TV", "Server at ${state.hostIp}:${state.port}", LogStatus.INFO)
                            sendPairingRequest()
                        }
                        is ClientConnectionState.Disconnected -> {
                            addLog(LogType.SYSTEM, "Disconnected from TV", "Connection closed", LogStatus.INFO)
                        }
                        is ClientConnectionState.Error -> {
                            addLog(LogType.SYSTEM, "Connection Error", state.message, LogStatus.FAILED)
                            _pairingMessage.value = "Connection failed: ${state.message}"
                        }
                        ClientConnectionState.Connecting -> {
                            addLog(LogType.SYSTEM, "Connecting to TV...", "IP: ${_tvIp.value}:${_tvPort.value}", LogStatus.INFO)
                        }
                    }
                }
            }.onFailure { e ->
                Log.e("MobileServiceManager", "Error in connection state collector: ${e.localizedMessage}", e)
            }
        }
    }

    fun checkNotificationListenerPermission(): Boolean {
        val isGranted = NotificationManagerCompat.getEnabledListenerPackages(appContext).contains(appContext.packageName)
        if (!isGranted) {
            addLog(
                LogType.SYSTEM,
                "Notification Access Missing",
                "Notification Listener Access is NOT granted in Android Settings. Grant Notification Access for Notify2TV so notifications can be captured.",
                LogStatus.FAILED
            )
        }
        return isGranted
    }

    companion object {
        @Volatile
        private var INSTANCE: MobileServiceManager? = null

        fun getInstance(context: Context): MobileServiceManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: MobileServiceManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    fun updateTargetTv(ip: String, port: Int, pin: String) {
        _tvIp.value = ip
        _tvPort.value = port
        _tvPin.value = pin
        runCatching {
            prefs?.edit()
                ?.putString("tv_ip", ip)
                ?.putInt("tv_port", port)
                ?.putString("tv_pin", pin)
                ?.apply()
        }
    }

    fun toggleForwarding(enabled: Boolean) {
        _isForwardingEnabled.value = enabled
        runCatching {
            prefs?.edit()?.putBoolean("forwarding_enabled", enabled)?.apply()
        }
        addLog(
            LogType.SYSTEM,
            if (enabled) "Forwarding Enabled" else "Forwarding Paused",
            "Service status changed",
            LogStatus.INFO
        )
    }

    fun setIgnorePersistentEnabled(enabled: Boolean) {
        _isIgnorePersistentEnabled.value = enabled
        runCatching {
            prefs?.edit()?.putBoolean("ignore_persistent_notifications", enabled)?.apply()
        }
        addLog(
            LogType.SYSTEM,
            "Ignore Persistent Setting",
            "Ignore persistent/ongoing notifications set to ${if (enabled) "ENABLED" else "DISABLED"}",
            LogStatus.INFO
        )
    }

    fun setExpandedCameraBannerEnabled(enabled: Boolean) {
        _isExpandedCameraBannerEnabled.value = enabled
        runCatching {
            prefs?.edit()?.putBoolean("expanded_camera_banner_enabled", enabled)?.apply()
        }
        addLog(
            LogType.SYSTEM,
            "Expanded Camera Banner Setting",
            "Large camera image banner set to ${if (enabled) "ENABLED" else "DISABLED"}",
            LogStatus.INFO
        )
    }

    fun connectAndPair(ip: String, port: Int, pin: String) {
        updateTargetTv(ip, port, pin)
        _pairingMessage.value = null
        if (ip.isBlank()) {
            _pairingMessage.value = "Please enter TV IP address"
            return
        }
        client.connect(ip, port)
    }

    fun disconnect() {
        client.disconnect()
        _pairingStatus.value = PairingStatus.PENDING
        runCatching {
            prefs?.edit()?.putString("pairing_status", PairingStatus.PENDING.name)?.apply()
        }
    }

    private fun sendPairingRequest() {
        val deviceName = "${Build.MANUFACTURER} ${Build.MODEL}"
        val deviceId = "mobile_${Build.MODEL.replace(" ", "_")}"

        scope.launch(Dispatchers.IO) {
            val localIp = NetworkUtils.getLocalIpAddress() ?: "127.0.0.1"
            val pairingPayload = PairingPayload(
                pairingCode = _tvPin.value,
                ip = localIp,
                port = _tvPort.value,
                deviceId = deviceId,
                deviceName = deviceName,
                clientType = ClientType.MOBILE,
                status = PairingStatus.PENDING
            )

            val sent = client.sendMessage(NetworkMessage.PairingRequest(pairingPayload))
            if (sent) {
                addLog(LogType.PAIRING, "Pairing Requested", "Sent PIN: ${_tvPin.value} to TV", LogStatus.SENT)
            } else {
                addLog(LogType.PAIRING, "Pairing Request Failed", "Could not send request", LogStatus.FAILED)
            }
        }
    }

    fun sendNotification(payload: NotificationPayload) {
        checkNotificationListenerPermission()

        val isCamera = CameraNotificationDetector.isCameraNotification(payload)
        val hasImage = !payload.bigPictureBase64.isNullOrBlank()
        val statusInfo = " (ImageAttached: $hasImage, CameraDetected: $isCamera)"

        if (!_isForwardingEnabled.value) {
            addLog(
                LogType.NOTIFICATION,
                "Forwarding Disabled",
                "Captured notification from ${payload.appName}: ${payload.title}$statusInfo but forwarding service is paused.",
                LogStatus.INFO
            )
            return
        }

        if (client.connectionState.value !is ClientConnectionState.Connected) {
            addLog(
                LogType.NOTIFICATION,
                "Captured notification from ${payload.appName}: ${payload.title}$statusInfo but TV is disconnected! Connect to TV to forward.",
                "${payload.title}: ${payload.body}",
                LogStatus.FAILED
            )
            return
        }

        scope.launch {
            val sent = client.sendMessage(NetworkMessage.Notification(payload))
            if (sent) {
                addLog(
                    LogType.NOTIFICATION,
                    "Forwarded notification ${payload.appName} to TV$statusInfo",
                    "${payload.title}: ${payload.body}",
                    LogStatus.SENT
                )
            } else {
                addLog(
                    LogType.NOTIFICATION,
                    "Failed to forward notification ${payload.appName}$statusInfo",
                    "${payload.title}: ${payload.body}",
                    LogStatus.FAILED
                )
            }
        }
    }

    fun sendTestCameraNotification() {
        val cameraSnapshotBase64 = TvReceiverManager.getInstance(appContext).createSampleCameraSnapshot()
        val testCameraPayload = NotificationPayload(
            id = "test_cam_${System.currentTimeMillis()}",
            appName = "Security Cam",
            packageName = "com.vlad411.notify2tv.camera",
            title = "Motion Detected at Front Door",
            body = "Front Door Security Camera detected motion in driveway.",
            category = "ALARM",
            bigPictureBase64 = cameraSnapshotBase64
        )
        sendNotification(testCameraPayload)
    }

    fun sendCall(payload: CallPayload) {
        if (!_isForwardingEnabled.value) return
        if (client.connectionState.value !is ClientConnectionState.Connected) return

        scope.launch {
            val sent = client.sendMessage(NetworkMessage.Call(payload))
            val callerInfo = payload.callerName ?: payload.callerNumber ?: "Unknown"
            if (sent) {
                addLog(
                    LogType.CALL,
                    "Call Alert (${payload.callType})",
                    "From/To $callerInfo",
                    LogStatus.SENT
                )
            } else {
                addLog(
                    LogType.CALL,
                    "Call Alert Failed",
                    "Could not send call alert for $callerInfo",
                    LogStatus.FAILED
                )
            }
        }
    }

    fun sendBannerPosition(position: BannerPosition) {
        if (client.connectionState.value is ClientConnectionState.Connected) {
            scope.launch {
                val sent = client.sendMessage(NetworkMessage.BannerPositionUpdate(position.name))
                if (sent) {
                    addLog(
                        LogType.SYSTEM,
                        "Banner Position Sent",
                        "Updated position to ${position.displayName}",
                        LogStatus.SENT
                    )
                }
            }
        }
    }

    fun setBannerTransparencyPercent(percent: Int) {
        val clamped = ((percent / 10) * 10).coerceIn(0, 100)
        _bannerTransparencyPercent.value = clamped
        runCatching {
            prefs?.edit()?.putInt("banner_transparency_percent", clamped)?.apply()
        }
        addLog(
            LogType.SYSTEM,
            "Banner Transparency Setting",
            "Banner transparency set to $clamped%",
            LogStatus.INFO
        )
        sendBannerTransparency(clamped)
    }

    fun sendBannerTransparency(percent: Int) {
        val clamped = percent.coerceIn(0, 100)
        if (client.connectionState.value is ClientConnectionState.Connected) {
            scope.launch {
                val sent = client.sendMessage(NetworkMessage.BannerTransparencyUpdate(clamped))
                if (sent) {
                    addLog(
                        LogType.SYSTEM,
                        "Banner Transparency Sent",
                        "Updated transparency to $clamped%",
                        LogStatus.SENT
                    )
                }
            }
        }
    }

    fun setBannerTimeoutSeconds(seconds: Int) {
        val validSeconds = if (seconds in listOf(3, 5, 7, 10)) seconds else 7
        _bannerTimeoutSeconds.value = validSeconds
        runCatching {
            prefs?.edit()?.putInt("banner_timeout_seconds", validSeconds)?.apply()
        }
        addLog(
            LogType.SYSTEM,
            "Banner Timeout Setting",
            "Banner timeout set to $validSeconds seconds",
            LogStatus.INFO
        )
        sendBannerTimeout(validSeconds)
    }

    fun sendBannerTimeout(seconds: Int) {
        val validSeconds = if (seconds in listOf(3, 5, 7, 10)) seconds else 7
        if (client.connectionState.value is ClientConnectionState.Connected) {
            scope.launch {
                val sent = client.sendMessage(NetworkMessage.BannerTimeoutUpdate(validSeconds))
                if (sent) {
                    addLog(
                        LogType.SYSTEM,
                        "Banner Timeout Sent",
                        "Updated timeout to $validSeconds seconds",
                        LogStatus.SENT
                    )
                }
            }
        }
    }

    private fun handleIncomingMessage(message: NetworkMessage) {
        when (message) {
            is NetworkMessage.PairingResponse -> {
                if (message.accepted) {
                    _pairingStatus.value = PairingStatus.ACCEPTED
                    runCatching {
                        prefs?.edit()?.putString("pairing_status", PairingStatus.ACCEPTED.name)?.apply()
                    }
                    _pairingMessage.value = message.message ?: "Pairing accepted by TV!"
                    addLog(LogType.PAIRING, "Pairing Accepted", _pairingMessage.value!!, LogStatus.RECEIVED)
                } else {
                    _pairingStatus.value = PairingStatus.REJECTED
                    runCatching {
                        prefs?.edit()?.putString("pairing_status", PairingStatus.REJECTED.name)?.apply()
                    }
                    _pairingMessage.value = message.message ?: "PIN rejected or pairing denied by TV"
                    addLog(LogType.PAIRING, "Pairing Denied", _pairingMessage.value!!, LogStatus.FAILED)
                }
            }
            is NetworkMessage.Action -> {
                addLog(LogType.NOTIFICATION, "Action Received from TV", "Action ID: ${message.actionId}", LogStatus.RECEIVED)
                actionHandler?.invoke(message)
            }
            is NetworkMessage.BannerTransparencyUpdate -> {
                val clamped = message.percent.coerceIn(0, 100)
                _bannerTransparencyPercent.value = clamped
                runCatching {
                    prefs?.edit()?.putInt("banner_transparency_percent", clamped)?.apply()
                }
                addLog(LogType.SYSTEM, "Banner Transparency Received", "Updated to $clamped%", LogStatus.RECEIVED)
            }
            is NetworkMessage.BannerTimeoutUpdate -> {
                val validSeconds = if (message.seconds in listOf(3, 5, 7, 10)) message.seconds else 7
                _bannerTimeoutSeconds.value = validSeconds
                runCatching {
                    prefs?.edit()?.putInt("banner_timeout_seconds", validSeconds)?.apply()
                }
                addLog(LogType.SYSTEM, "Banner Timeout Received", "Updated to $validSeconds seconds", LogStatus.RECEIVED)
            }
            else -> {
                Log.d("MobileServiceManager", "Received network message: ${message::class.simpleName}")
            }
        }
    }

    fun addLog(type: LogType, title: String, description: String, status: LogStatus) {
        val entry = ForwardingLogEntry(
            type = type,
            title = title,
            description = description,
            status = status
        )
        val current = _logs.value.toMutableList()
        current.add(0, entry)
        if (current.size > 100) {
            current.removeAt(current.size - 1)
        }
        _logs.value = current
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }
}
