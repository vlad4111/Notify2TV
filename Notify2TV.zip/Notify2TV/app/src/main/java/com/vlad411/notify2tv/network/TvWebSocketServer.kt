package com.vlad411.notify2tv.network

import com.vlad411.notify2tv.model.NetworkMessage
import io.ktor.server.application.install
import io.ktor.server.cio.CIO
import io.ktor.server.cio.CIOApplicationEngine
import io.ktor.server.engine.EmbeddedServer
import io.ktor.server.engine.embeddedServer
import io.ktor.server.routing.routing
import io.ktor.server.websocket.DefaultWebSocketServerSession
import io.ktor.server.websocket.WebSockets
import io.ktor.server.websocket.webSocket
import io.ktor.websocket.Frame
import io.ktor.websocket.readText
import io.ktor.websocket.send
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import kotlin.time.Duration.Companion.seconds

sealed interface ServerState {
    object Stopped : ServerState
    object Starting : ServerState
    data class Running(val hostIp: String, val port: Int) : ServerState
    data class Error(val message: String) : ServerState
}

class TvWebSocketServer(
    private val port: Int = NetworkUtils.DEFAULT_PORT
) {
    private var serverEngine: EmbeddedServer<CIOApplicationEngine, CIOApplicationEngine.Configuration>? = null
    private val connectedSessions = ConcurrentHashMap<String, DefaultWebSocketServerSession>()

    private val _serverState = MutableStateFlow<ServerState>(ServerState.Stopped)
    val serverState: StateFlow<ServerState> = _serverState.asStateFlow()

    private val _incomingMessages = MutableSharedFlow<NetworkMessage>(extraBufferCapacity = 64)
    val incomingMessages: SharedFlow<NetworkMessage> = _incomingMessages.asSharedFlow()

    private val _connectedClientsCount = MutableStateFlow(0)
    val connectedClientsCount: StateFlow<Int> = _connectedClientsCount.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    fun start() {
        if (_serverState.value is ServerState.Running || _serverState.value is ServerState.Starting) return
        _serverState.value = ServerState.Starting

        scope.launch {
            try {
                val localIp = NetworkUtils.getLocalIpAddress() ?: "0.0.0.0"
                val engine = embeddedServer(CIO, port = port) {
                    install(WebSockets) {
                        pingPeriodMillis = 15000
                        timeoutMillis = 30000
                        maxFrameSize = Long.MAX_VALUE
                        masking = false
                    }

                    routing {
                        webSocket(NetworkUtils.WS_PATH) {
                            val sessionId = java.util.UUID.randomUUID().toString()
                            connectedSessions[sessionId] = this
                            _connectedClientsCount.value = connectedSessions.size

                            try {
                                for (frame in incoming) {
                                    if (frame is Frame.Text) {
                                        val text = frame.readText()
                                        val message = NetworkMessage.fromJson(text)
                                        if (message != null) {
                                            when (message) {
                                                is NetworkMessage.Ping -> {
                                                    send(Frame.Text(NetworkMessage.Pong().toJson()))
                                                }
                                                else -> {
                                                    _incomingMessages.emit(message)
                                                }
                                            }
                                        }
                                    }
                                }
                            } catch (e: Exception) {
                                // Connection closed or error
                            } finally {
                                connectedSessions.remove(sessionId)
                                _connectedClientsCount.value = connectedSessions.size
                            }
                        }
                    }
                }
                serverEngine = engine
                engine.start(wait = false)
                _serverState.value = ServerState.Running(localIp, port)
            } catch (e: Exception) {
                _serverState.value = ServerState.Error(e.localizedMessage ?: "Failed to start server")
            }
        }
    }

    fun stop() {
        scope.launch {
            try {
                serverEngine?.stop(1000, 2000)
                serverEngine = null
                connectedSessions.clear()
                _connectedClientsCount.value = 0
                _serverState.value = ServerState.Stopped
            } catch (e: Exception) {
                _serverState.value = ServerState.Stopped
            }
        }
    }

    suspend fun broadcastMessage(message: NetworkMessage) {
        val json = message.toJson()
        connectedSessions.values.forEach { session ->
            runCatching {
                session.send(Frame.Text(json))
            }
        }
    }

    suspend fun sendMessageToSession(sessionId: String, message: NetworkMessage): Boolean {
        val session = connectedSessions[sessionId] ?: return false
        return runCatching {
            session.send(Frame.Text(message.toJson()))
            true
        }.getOrDefault(false)
    }
}
