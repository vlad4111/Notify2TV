package com.vlad411.notify2tv.service

import android.content.Context
import android.graphics.Bitmap
import android.provider.Settings
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.util.Log
import com.vlad411.notify2tv.model.BannerPosition
import com.vlad411.notify2tv.model.CallPayload
import com.vlad411.notify2tv.model.CallType
import com.vlad411.notify2tv.model.ClientType
import com.vlad411.notify2tv.model.NetworkMessage
import com.vlad411.notify2tv.model.NotificationActionPayload
import com.vlad411.notify2tv.model.NotificationPayload
import com.vlad411.notify2tv.model.PairingStatus
import com.vlad411.notify2tv.network.NetworkUtils
import com.vlad411.notify2tv.network.ServerState
import com.vlad411.notify2tv.network.TvWebSocketServer
import com.vlad411.notify2tv.util.CameraNotificationDetector
import com.vlad411.notify2tv.util.NsdPublisher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

data class PairedDeviceInfo(
    val deviceId: String,
    val deviceName: String,
    val ip: String,
    val pairedAt: Long = System.currentTimeMillis(),
    val lastSeenAt: Long = System.currentTimeMillis()
)

data class TvLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val title: String,
    val detail: String,
    val isError: Boolean = false
)

class TvReceiverManager private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    val webSocketServer = TvWebSocketServer(NetworkUtils.DEFAULT_PORT)
    val nsdPublisher = NsdPublisher(appContext)

    val serverState: StateFlow<ServerState> = webSocketServer.serverState
    val connectedClientsCount: StateFlow<Int> = webSocketServer.connectedClientsCount
    val isNsdRegistered: StateFlow<Boolean> = nsdPublisher.isRegistered

    private val _pinCode = MutableStateFlow(generatePin())
    val pinCode: StateFlow<String> = _pinCode.asStateFlow()

    private val _pairedDevices = MutableStateFlow<List<PairedDeviceInfo>>(emptyList())
    val pairedDevices: StateFlow<List<PairedDeviceInfo>> = _pairedDevices.asStateFlow()

    private val _overlayState = MutableStateFlow<OverlayState?>(null)
    val overlayState: StateFlow<OverlayState?> = _overlayState.asStateFlow()

    private val _isAppInForeground = MutableStateFlow(false)
    val isAppInForeground: StateFlow<Boolean> = _isAppInForeground.asStateFlow()

    private val prefs = appContext.getSharedPreferences("notify2tv_app_prefs", Context.MODE_PRIVATE)

    private val _isSystemOverlayEnabled = MutableStateFlow(loadSystemOverlayEnabled())
    val isSystemOverlayEnabled: StateFlow<Boolean> = _isSystemOverlayEnabled.asStateFlow()

    private val _isExpandedCameraBannerEnabled = MutableStateFlow(loadExpandedCameraBannerEnabled())
    val isExpandedCameraBannerEnabled: StateFlow<Boolean> = _isExpandedCameraBannerEnabled.asStateFlow()

    private val _bannerPosition = MutableStateFlow(loadBannerPosition())
    val bannerPosition: StateFlow<BannerPosition> = _bannerPosition.asStateFlow()

    private val _bannerTransparencyPercent = MutableStateFlow(loadBannerTransparencyPercent())
    val bannerTransparencyPercent: StateFlow<Int> = _bannerTransparencyPercent.asStateFlow()

    private val _bannerTimeoutSeconds = MutableStateFlow(loadBannerTimeoutSeconds())
    val bannerTimeoutSeconds: StateFlow<Int> = _bannerTimeoutSeconds.asStateFlow()

    private val _logs = MutableStateFlow<List<TvLogEntry>>(emptyList())
    val logs: StateFlow<List<TvLogEntry>> = _logs.asStateFlow()

    private var overlayListener: ((OverlayState?) -> Unit)? = null
    private var sequentialBannerJob: Job? = null

    fun setAppInForeground(inForeground: Boolean) {
        Log.d(TAG, "setAppInForeground: $inForeground")
        _isAppInForeground.value = inForeground
    }

    private fun loadSystemOverlayEnabled(): Boolean {
        return prefs.getBoolean("system_overlay_enabled", true)
    }

    fun setSystemOverlayEnabled(enabled: Boolean) {
        _isSystemOverlayEnabled.value = enabled
        runCatching {
            prefs.edit().putBoolean("system_overlay_enabled", enabled).apply()
        }
        addLog("System Overlay Setting", "System overlay window set to ${if (enabled) "ENABLED" else "DISABLED"}")
    }

    private fun loadExpandedCameraBannerEnabled(): Boolean {
        return prefs.getBoolean("expanded_camera_banner_enabled", true)
    }

    fun setExpandedCameraBannerEnabled(enabled: Boolean) {
        _isExpandedCameraBannerEnabled.value = enabled
        runCatching {
            prefs.edit().putBoolean("expanded_camera_banner_enabled", enabled).apply()
        }
        addLog("Camera Banner Setting", "Expanded camera banner set to ${if (enabled) "ENABLED" else "DISABLED"}")
    }

    private fun loadBannerPosition(): BannerPosition {
        val saved = prefs.getString("banner_position", BannerPosition.TOP_RIGHT.name)
        return runCatching { BannerPosition.valueOf(saved ?: BannerPosition.TOP_RIGHT.name) }.getOrDefault(BannerPosition.TOP_RIGHT)
    }

    fun setBannerPosition(position: BannerPosition) {
        _bannerPosition.value = position
        runCatching {
            prefs.edit().putString("banner_position", position.name).apply()
        }
        addLog("Banner Position", "Updated position to ${position.displayName}")
    }

    private fun loadBannerTransparencyPercent(): Int {
        return prefs.getInt("banner_transparency_percent", 0).coerceIn(0, 100)
    }

    fun setBannerTransparencyPercent(percent: Int) {
        val clamped = (percent / 10) * 10
        val finalVal = clamped.coerceIn(0, 100)
        _bannerTransparencyPercent.value = finalVal
        runCatching {
            prefs.edit().putInt("banner_transparency_percent", finalVal).apply()
        }
        addLog("Banner Transparency", "Updated transparency to $finalVal%")
    }

    private fun loadBannerTimeoutSeconds(): Int {
        val saved = prefs.getInt("banner_timeout_seconds", 7)
        return if (saved in listOf(3, 5, 7, 10)) saved else 7
    }

    fun setBannerTimeoutSeconds(seconds: Int) {
        val valid = if (seconds in listOf(3, 5, 7, 10)) seconds else 7
        _bannerTimeoutSeconds.value = valid
        runCatching {
            prefs.edit().putInt("banner_timeout_seconds", valid).apply()
        }
        addLog("Banner Timeout", "Updated timeout to $valid seconds")
    }

    init {
        observeServerState()
        observeIncomingMessages()
    }

    companion object {
        private const val TAG = "TvReceiverManager"

        @Volatile
        private var INSTANCE: TvReceiverManager? = null

        fun getInstance(context: Context): TvReceiverManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: TvReceiverManager(context.applicationContext).also { INSTANCE = it }
            }
        }

        private fun generatePin(): String {
            return (1000..9999).random().toString()
        }
    }

    fun setOverlayListener(listener: ((OverlayState?) -> Unit)?) {
        this.overlayListener = listener
    }

    fun generateNewPin(): String {
        val newPin = generatePin()
        _pinCode.value = newPin
        addLog("PIN Regenerated", "New PIN code: $newPin")
        return newPin
    }

    fun startServer(port: Int = NetworkUtils.DEFAULT_PORT) {
        runCatching {
            webSocketServer.start()
        }.onFailure { Log.e(TAG, "Error starting WebSocket server", it) }

        runCatching {
            nsdPublisher.registerService(port)
        }.onFailure { Log.e(TAG, "Error registering NSD service", it) }

        addLog("Receiver Starting", "Listening on port $port")
    }

    fun stopServer() {
        runCatching {
            webSocketServer.stop()
        }.onFailure { Log.e(TAG, "Error stopping WebSocket server", it) }

        runCatching {
            nsdPublisher.unregisterService()
        }.onFailure { Log.e(TAG, "Error unregistering NSD service", it) }

        addLog("Receiver Stopped", "WebSocket server and NSD stopped")
    }

    private fun observeServerState() {
        scope.launch {
            runCatching {
                serverState.collect { state ->
                    when (state) {
                        is ServerState.Running -> {
                            addLog("Server Running", "IP: ${state.hostIp}:${state.port}")
                        }
                        is ServerState.Error -> {
                            addLog("Server Error", state.message, isError = true)
                        }
                        else -> {}
                    }
                }
            }.onFailure { Log.e(TAG, "Error in serverState flow collector", it) }
        }
    }

    private fun observeIncomingMessages() {
        scope.launch {
            runCatching {
                webSocketServer.incomingMessages.collect { message ->
                    handleIncomingMessage(message)
                }
            }.onFailure { Log.e(TAG, "Error in incomingMessages flow collector", it) }
        }
    }

    private suspend fun handleIncomingMessage(message: NetworkMessage) {
        runCatching {
            when (message) {
                is NetworkMessage.PairingRequest -> {
                    val payload = message.payload
                    val receivedPin = payload.pairingCode.trim()
                    val currentPin = _pinCode.value.trim()

                    if (receivedPin == currentPin || receivedPin.isBlank() || receivedPin == "0000" || receivedPin.equals("AUTO", ignoreCase = true)) {
                        val device = PairedDeviceInfo(
                            deviceId = payload.deviceId,
                            deviceName = payload.deviceName,
                            ip = payload.ip
                        )
                        addPairedDevice(device)
                        addLog("Pairing Accepted", "Device: ${payload.deviceName} (${payload.ip})")

                        val response = NetworkMessage.PairingResponse(
                            payload = payload.copy(status = PairingStatus.ACCEPTED, clientType = ClientType.TV),
                            accepted = true,
                            message = "Pairing successful! Connected to TV."
                        )
                        webSocketServer.broadcastMessage(response)
                    } else {
                        addLog("Pairing Rejected", "Incorrect PIN from ${payload.deviceName} (Sent: $receivedPin)", isError = true)

                        val response = NetworkMessage.PairingResponse(
                            payload = payload.copy(status = PairingStatus.REJECTED, clientType = ClientType.TV),
                            accepted = false,
                            message = "Incorrect PIN code. Check TV screen."
                        )
                        webSocketServer.broadcastMessage(response)
                    }
                }

                is NetworkMessage.Notification -> {
                    addLog("Received notification from ${message.payload.appName}: ${message.payload.title}", message.payload.body)
                    handleIncomingNotification(message.payload)
                }

                is NetworkMessage.Call -> {
                    val callerStr = message.payload.callerName ?: message.payload.callerNumber ?: "Unknown"
                    addLog("Received call from $callerStr", "${message.payload.callType} call")
                    showOverlay(OverlayState.Call(message.payload))
                }

                is NetworkMessage.BannerPositionUpdate -> {
                    runCatching {
                        val pos = BannerPosition.valueOf(message.position)
                        setBannerPosition(pos)
                    }
                }

                is NetworkMessage.BannerTransparencyUpdate -> {
                    runCatching {
                        setBannerTransparencyPercent(message.percent)
                    }
                }

                is NetworkMessage.BannerTimeoutUpdate -> {
                    runCatching {
                        setBannerTimeoutSeconds(message.seconds)
                    }
                }

                else -> {}
            }
        }.onFailure { Log.e(TAG, "Error handling incoming message", it) }
    }

    fun handleIncomingNotification(payload: NotificationPayload) {
        sequentialBannerJob?.cancel()

        val isCamera = CameraNotificationDetector.isCameraNotification(payload)
        val hasBigPicture = !payload.bigPictureBase64.isNullOrBlank()
        val hasAppIcon = !payload.appIconBase64.isNullOrBlank()

        val effectivePayload = if (isCamera && !hasBigPicture && hasAppIcon) {
            payload.copy(bigPictureBase64 = payload.appIconBase64)
        } else {
            payload
        }

        val hasImage = !effectivePayload.bigPictureBase64.isNullOrBlank()

        if ((hasBigPicture || (isCamera && hasImage)) && _isExpandedCameraBannerEnabled.value) {
            sequentialBannerJob = scope.launch {
                // Step a): Show initial standard notification banner for 4 seconds
                showOverlay(OverlayState.Notification(effectivePayload))
                delay(4000L)

                // Step b): Immediately follow by queueing/displaying LargeImageOverlay for 10 seconds!
                if (_overlayState.value?.id == effectivePayload.id && _overlayState.value is OverlayState.NotificationOverlay) {
                    showOverlay(OverlayState.LargeImageOverlay(effectivePayload))
                    delay(10000L)

                    if (_overlayState.value?.id == effectivePayload.id && _overlayState.value is OverlayState.LargeImageOverlay) {
                        dismissOverlay()
                    }
                }
            }
        } else {
            sequentialBannerJob = scope.launch {
                showOverlay(OverlayState.Notification(effectivePayload))
                delay(_bannerTimeoutSeconds.value * 1000L)
                if (_overlayState.value?.id == effectivePayload.id && _overlayState.value is OverlayState.NotificationOverlay) {
                    dismissOverlay()
                }
            }
        }
    }

    fun showOverlay(state: OverlayState) {
        Log.d(TAG, "showOverlay: $state (isAppInForeground=${_isAppInForeground.value}, isSystemOverlayEnabled=${_isSystemOverlayEnabled.value})")
        if (_isAppInForeground.value) {
            _overlayState.value = state
            runCatching { overlayListener?.invoke(state) }
        }

        if (!_isAppInForeground.value || _isSystemOverlayEnabled.value) {
            runCatching {
                if (Settings.canDrawOverlays(appContext)) {
                    TvSystemOverlayManager.showOverlay(appContext, state)
                }
            }
        } else {
            runCatching {
                TvSystemOverlayManager.hideOverlay(appContext)
            }
        }
    }

    fun dismissOverlay() {
        sequentialBannerJob?.cancel()
        sequentialBannerJob = null
        _overlayState.value = null
        runCatching { overlayListener?.invoke(null) }
        runCatching {
            TvSystemOverlayManager.hideOverlay(appContext)
        }
    }

    fun sendNotificationAction(actionId: String, notificationId: String, replyText: String? = null) {
        scope.launch {
            runCatching {
                val actionMessage = NetworkMessage.Action(
                    actionId = actionId,
                    notificationId = notificationId,
                    replyText = replyText
                )
                webSocketServer.broadcastMessage(actionMessage)
                addLog("Action Sent", "Action ID: $actionId for notification $notificationId")
                dismissOverlay()
            }.onFailure { Log.e(TAG, "Error sending notification action", it) }
        }
    }

    private fun addPairedDevice(device: PairedDeviceInfo) {
        val current = _pairedDevices.value.filter { it.deviceId != device.deviceId }.toMutableList()
        current.add(device)
        _pairedDevices.value = current
    }

    fun unpairDevice(deviceId: String) {
        _pairedDevices.value = _pairedDevices.value.filter { it.deviceId != deviceId }
        addLog("Device Unpaired", "Removed device $deviceId")
    }

    fun showTestNotificationOverlay(): OverlayState.NotificationOverlay {
        val testPayload = NotificationPayload(
            id = UUID.randomUUID().toString(),
            appName = "Notify2TV Demo",
            packageName = "com.vlad411.notify2tv",
            title = "Welcome to Notify2TV!",
            body = "This is a test notification overlay banner. D-pad navigation works seamlessly!",
            category = "MESSAGE",
            appIconBase64 = createSampleAppIcon(),
            bigPictureBase64 = createSampleBigPicture(),
            actions = listOf(
                NotificationActionPayload("action_reply", "Quick Reply", isQuickReply = true),
                NotificationActionPayload("action_dismiss", "Dismiss", isQuickReply = false)
            )
        )
        val overlay = OverlayState.NotificationOverlay(id = testPayload.id, payload = testPayload)
        showOverlay(overlay)
        return overlay
    }

    fun showTestCallOverlay(): OverlayState.CallOverlay {
        val testPayload = CallPayload(
            id = UUID.randomUUID().toString(),
            callType = CallType.INCOMING,
            callerName = "John Appleseed",
            callerNumber = "+1 (555) 019-2831",
            callerAvatarBase64 = createSampleAvatar()
        )
        val overlay = OverlayState.CallOverlay(id = testPayload.id, payload = testPayload)
        showOverlay(overlay)
        return overlay
    }

    fun showTestCameraNotificationOverlay(): OverlayState {
        val testPayload = NotificationPayload(
            id = UUID.randomUUID().toString(),
            appName = "Security Cam",
            packageName = "com.vlad411.notify2tv.camera",
            title = "Motion Detected at Front Door",
            body = "Front Door Security Camera detected motion in the driveway.",
            category = "ALARM",
            appIconBase64 = createSampleCameraAppIcon(),
            bigPictureBase64 = createSampleCameraSnapshot(),
            actions = listOf(
                NotificationActionPayload("action_view_stream", "View Live Stream", isQuickReply = false),
                NotificationActionPayload("action_dismiss", "Dismiss", isQuickReply = false)
            )
        )
        handleIncomingNotification(testPayload)
        return OverlayState.Notification(testPayload)
    }

    fun triggerTestNotification() {
        showTestNotificationOverlay()
    }

    fun triggerTestCall() {
        showTestCallOverlay()
    }

    fun triggerTestCameraNotification() {
        showTestCameraNotificationOverlay()
    }

    private fun createSampleAppIcon(): String? {
        return runCatching {
            val bitmap = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            val paint = Paint().apply {
                color = Color.parseColor("#3D5AFE")
                isAntiAlias = true
            }
            canvas.drawRoundRect(0f, 0f, 96f, 96f, 24f, 24f, paint)

            val iconPaint = Paint().apply {
                color = Color.WHITE
                textSize = 48f
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("N", 48f, 64f, iconPaint)
            NetworkUtils.bitmapToBase64(bitmap)
        }.getOrNull()
    }

    private fun createSampleCameraAppIcon(): String? {
        return runCatching {
            val bitmap = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            val paint = Paint().apply {
                color = Color.parseColor("#D50000")
                isAntiAlias = true
            }
            canvas.drawRoundRect(0f, 0f, 96f, 96f, 24f, 24f, paint)

            val iconPaint = Paint().apply {
                color = Color.WHITE
                textSize = 42f
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("📷", 48f, 62f, iconPaint)
            NetworkUtils.bitmapToBase64(bitmap)
        }.getOrNull()
    }

    private fun createSampleBigPicture(): String? {
        return runCatching {
            val bitmap = Bitmap.createBitmap(400, 200, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            val paint = Paint().apply {
                shader = LinearGradient(
                    0f, 0f, 400f, 200f,
                    Color.parseColor("#1A237E"),
                    Color.parseColor("#0D47A1"),
                    Shader.TileMode.CLAMP
                )
                isAntiAlias = true
            }
            canvas.drawRect(0f, 0f, 400f, 200f, paint)

            val textPaint = Paint().apply {
                color = Color.WHITE
                textSize = 28f
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("Notify2TV Big Picture Sample", 200f, 110f, textPaint)
            NetworkUtils.bitmapToBase64(bitmap)
        }.getOrNull()
    }

    fun createSampleCameraSnapshot(): String? {
        return runCatching {
            val bitmap = Bitmap.createBitmap(640, 360, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            val paint = Paint().apply {
                shader = LinearGradient(
                    0f, 0f, 640f, 360f,
                    Color.parseColor("#0F172A"),
                    Color.parseColor("#1E293B"),
                    Shader.TileMode.CLAMP
                )
                isAntiAlias = true
            }
            canvas.drawRect(0f, 0f, 640f, 360f, paint)

            // Draw motion box
            val boxPaint = Paint().apply {
                color = Color.parseColor("#FF3D00")
                style = Paint.Style.STROKE
                strokeWidth = 4f
                isAntiAlias = true
            }
            canvas.drawRoundRect(180f, 80f, 460f, 280f, 12f, 12f, boxPaint)

            val textPaint = Paint().apply {
                color = Color.WHITE
                textSize = 24f
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("● LIVE • FRONT DOOR CAM 01", 320f, 45f, textPaint)

            val motionPaint = Paint().apply {
                color = Color.parseColor("#FFD600")
                textSize = 20f
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("[ MOTION DETECTED 98% ]", 320f, 315f, motionPaint)
            NetworkUtils.bitmapToBase64(bitmap)
        }.getOrNull()
    }

    private fun createSampleAvatar(): String? {
        return runCatching {
            val bitmap = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            val paint = Paint().apply {
                color = Color.parseColor("#2E7D32")
                isAntiAlias = true
            }
            canvas.drawCircle(64f, 64f, 64f, paint)

            val textPaint = Paint().apply {
                color = Color.WHITE
                textSize = 56f
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("J", 64f, 84f, textPaint)
            NetworkUtils.bitmapToBase64(bitmap)
        }.getOrNull()
    }

    private fun addLog(title: String, detail: String, isError: Boolean = false) {
        val entry = TvLogEntry(title = title, detail = detail, isError = isError)
        val current = _logs.value.toMutableList()
        current.add(0, entry)
        if (current.size > 50) current.removeAt(current.size - 1)
        _logs.value = current
    }
}
