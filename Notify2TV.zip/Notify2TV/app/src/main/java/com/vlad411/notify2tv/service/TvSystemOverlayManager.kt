package com.vlad411.notify2tv.service

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.ViewGroup
import android.view.WindowManager
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.vlad411.notify2tv.ui.overlay.TvOverlayBanner
import com.vlad411.notify2tv.ui.theme.Notify2TVTheme
import com.vlad411.notify2tv.util.CameraNotificationDetector
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

object TvSystemOverlayManager {

    private const val TAG = "TvSystemOverlayManager"

    private val mainHandler = Handler(Looper.getMainLooper())
    private val managerScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var windowManager: WindowManager? = null
    private var composeView: ComposeView? = null
    private var overlayLifecycleOwner: OverlayLifecycleOwner? = null
    private var autoDismissJob: Job? = null

    fun showOverlay(context: Context, overlayState: OverlayState) {
        val appContext = context.applicationContext
        if (Looper.myLooper() == Looper.getMainLooper()) {
            showOverlayInternal(appContext, overlayState)
        } else {
            mainHandler.post {
                showOverlayInternal(appContext, overlayState)
            }
        }
    }

    fun hideOverlay(context: Context) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            hideOverlayInternal()
        } else {
            mainHandler.post {
                hideOverlayInternal()
            }
        }
    }

    private fun showOverlayInternal(context: Context, overlayState: OverlayState) {
        if (!Settings.canDrawOverlays(context)) {
            Log.w(TAG, "Cannot draw overlay: SYSTEM_ALERT_WINDOW permission not granted")
            return
        }

        val wm = (context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager) ?: return
        windowManager = wm

        val receiverManager = TvReceiverManager.getInstance(context)
        val bannerPosition = receiverManager.bannerPosition.value
        val bannerTransparencyPercent = receiverManager.bannerTransparencyPercent.value
        val configuredTimeout = receiverManager.bannerTimeoutSeconds.value

        val timeoutSeconds = when (overlayState) {
            is OverlayState.NotificationOverlay -> {
                val isCamera = CameraNotificationDetector.isCameraNotification(overlayState.payload)
                val hasImage = !overlayState.payload.bigPictureBase64.isNullOrBlank()
                if ((hasImage || isCamera) && receiverManager.isExpandedCameraBannerEnabled.value) 4 else configuredTimeout
            }
            is OverlayState.LargeImageOverlay -> 10
            is OverlayState.CallOverlay -> configuredTimeout
        }

        autoDismissJob?.cancel()

        if (composeView == null) {
            val lifecycleOwner = OverlayLifecycleOwner()
            lifecycleOwner.performRestore(null)
            lifecycleOwner.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
            lifecycleOwner.handleLifecycleEvent(Lifecycle.Event.ON_START)
            lifecycleOwner.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
            overlayLifecycleOwner = lifecycleOwner

            val view = ComposeView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                setBackgroundColor(Color.TRANSPARENT)
                setViewTreeLifecycleOwner(lifecycleOwner)
                setViewTreeViewModelStoreOwner(lifecycleOwner)
                setViewTreeSavedStateRegistryOwner(lifecycleOwner)
            }

            val layoutParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                width = WindowManager.LayoutParams.WRAP_CONTENT
                height = WindowManager.LayoutParams.WRAP_CONTENT
                gravity = bannerPosition.gravity
                x = 32
                y = 32
                format = PixelFormat.TRANSLUCENT
            }

            view.setContent {
                Notify2TVTheme(darkTheme = true) {
                    Box(
                        modifier = Modifier.wrapContentSize()
                    ) {
                        TvOverlayBanner(
                            overlayState = overlayState,
                            bannerPosition = bannerPosition,
                            timeoutSeconds = timeoutSeconds,
                            transparencyPercent = bannerTransparencyPercent,
                            onDismiss = {
                                TvReceiverManager.getInstance(context).dismissOverlay()
                                hideOverlay(context)
                            },
                            onActionClicked = { actionId, notificationId ->
                                TvReceiverManager.getInstance(context).sendNotificationAction(actionId, notificationId)
                                hideOverlay(context)
                            }
                        )
                    }
                }
            }

            runCatching {
                wm.addView(view, layoutParams)
                composeView = view
                Log.d(TAG, "Overlay banner view added directly to WindowManager successfully")
            }.onFailure {
                Log.e(TAG, "Failed to add overlay view to WindowManager", it)
            }
        } else {
            val view = composeView ?: return
            view.setBackgroundColor(Color.TRANSPARENT)
            val layoutParams = (view.layoutParams as? WindowManager.LayoutParams)?.apply {
                width = WindowManager.LayoutParams.WRAP_CONTENT
                height = WindowManager.LayoutParams.WRAP_CONTENT
                gravity = bannerPosition.gravity
                x = 32
                y = 32
                format = PixelFormat.TRANSLUCENT
            }
            if (layoutParams != null) {
                runCatching { wm.updateViewLayout(view, layoutParams) }
            }

            view.setContent {
                Notify2TVTheme(darkTheme = true) {
                    Box(
                        modifier = Modifier.wrapContentSize()
                    ) {
                        TvOverlayBanner(
                            overlayState = overlayState,
                            bannerPosition = bannerPosition,
                            timeoutSeconds = timeoutSeconds,
                            transparencyPercent = bannerTransparencyPercent,
                            onDismiss = {
                                TvReceiverManager.getInstance(context).dismissOverlay()
                                hideOverlay(context)
                            },
                            onActionClicked = { actionId, notificationId ->
                                TvReceiverManager.getInstance(context).sendNotificationAction(actionId, notificationId)
                                hideOverlay(context)
                            }
                        )
                    }
                }
            }
        }

        // Schedule auto dismissal after timeoutSeconds + 0.5s safety backup
        val backupDelayMs = (timeoutSeconds * 1000L) + 500L
        autoDismissJob = managerScope.launch {
            delay(backupDelayMs)
            hideOverlayInternal()
        }
    }

    private fun hideOverlayInternal() {
        autoDismissJob?.cancel()
        autoDismissJob = null

        val view = composeView ?: return
        runCatching {
            windowManager?.removeView(view)
            Log.d(TAG, "Overlay banner view removed from WindowManager")
        }.onFailure {
            Log.e(TAG, "Failed to remove overlay view from WindowManager", it)
        }
        overlayLifecycleOwner?.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        overlayLifecycleOwner = null
        composeView = null
        windowManager = null
    }

    private class OverlayLifecycleOwner : LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
        private val lifecycleRegistry = LifecycleRegistry(this)
        private val savedStateRegistryController = SavedStateRegistryController.create(this)
        private val store = ViewModelStore()

        override val lifecycle: Lifecycle get() = lifecycleRegistry
        override val viewModelStore: ViewModelStore get() = store
        override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

        fun performRestore(savedState: Bundle?) {
            savedStateRegistryController.performRestore(savedState)
        }

        fun handleLifecycleEvent(event: Lifecycle.Event) {
            lifecycleRegistry.handleLifecycleEvent(event)
        }
    }
}
