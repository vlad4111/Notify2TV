package com.vlad411.notify2tv.service

import com.vlad411.notify2tv.model.CallPayload
import com.vlad411.notify2tv.model.NotificationPayload

sealed interface OverlayState {
    val id: String
    val createdAt: Long

    data class NotificationOverlay(
        override val id: String,
        val payload: NotificationPayload,
        override val createdAt: Long = System.currentTimeMillis()
    ) : OverlayState

    data class CallOverlay(
        override val id: String,
        val payload: CallPayload,
        override val createdAt: Long = System.currentTimeMillis()
    ) : OverlayState

    data class LargeImageOverlay(
        val payload: NotificationPayload,
        override val id: String = payload.id,
        override val createdAt: Long = System.currentTimeMillis()
    ) : OverlayState

    companion object {
        fun Notification(payload: NotificationPayload): NotificationOverlay =
            NotificationOverlay(id = payload.id, payload = payload)

        fun Call(payload: CallPayload): CallOverlay =
            CallOverlay(id = payload.id, payload = payload)

        fun LargeImage(payload: NotificationPayload): LargeImageOverlay =
            LargeImageOverlay(payload = payload)
    }
}
