package com.vlad411.notify2tv.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
enum class CallType {
    @SerialName("INCOMING") INCOMING,
    @SerialName("OUTGOING") OUTGOING,
    @SerialName("MISSED") MISSED,
    @SerialName("ENDED") ENDED,
    @SerialName("REJECTED") REJECTED
}

@Serializable
data class CallPayload(
    @SerialName("id") val id: String,
    @SerialName("call_type") val callType: CallType,
    @SerialName("caller_name") val callerName: String? = null,
    @SerialName("caller_number") val callerNumber: String? = null,
    @SerialName("caller_avatar_base64") val callerAvatarBase64: String? = null,
    @SerialName("timestamp") val timestamp: Long = System.currentTimeMillis()
)
