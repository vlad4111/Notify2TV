package com.vlad411.notify2tv.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import android.util.Log
import com.vlad411.notify2tv.model.CallPayload
import com.vlad411.notify2tv.model.CallType
import com.vlad411.notify2tv.service.MobileServiceManager
import com.vlad411.notify2tv.util.ContactsHelper

class PhoneCallReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "PhoneCallReceiver"

        private var lastState: String = TelephonyManager.EXTRA_STATE_IDLE
        private var lastNumber: String? = null
        private var currentCallId: String? = null
        private var isOutgoing: Boolean = false
    }

    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null || intent == null) return

        val action = intent.action
        if (action == Intent.ACTION_NEW_OUTGOING_CALL) {
            val outgoingNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER)
            lastNumber = outgoingNumber
            isOutgoing = true
            currentCallId = "call_${System.currentTimeMillis()}"

            dispatchCallAlert(
                context = context,
                callId = currentCallId!!,
                callType = CallType.OUTGOING,
                number = outgoingNumber
            )
            return
        }

        if (action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
            val stateStr = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
            val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                ?: intent.getStringExtra("incoming_number")
                ?: lastNumber

            if (number != null) {
                lastNumber = number
            }

            if (stateStr == lastState) {
                return
            }

            when (stateStr) {
                TelephonyManager.EXTRA_STATE_RINGING -> {
                    isOutgoing = false
                    currentCallId = "call_${System.currentTimeMillis()}"
                    dispatchCallAlert(
                        context = context,
                        callId = currentCallId!!,
                        callType = CallType.INCOMING,
                        number = lastNumber
                    )
                }
                TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                    if (lastState != TelephonyManager.EXTRA_STATE_RINGING && !isOutgoing) {
                        isOutgoing = true
                        currentCallId = "call_${System.currentTimeMillis()}"
                        dispatchCallAlert(
                            context = context,
                            callId = currentCallId!!,
                            callType = CallType.OUTGOING,
                            number = lastNumber
                        )
                    }
                }
                TelephonyManager.EXTRA_STATE_IDLE -> {
                    val callId = currentCallId ?: "call_${System.currentTimeMillis()}"
                    val callType = when {
                        lastState == TelephonyManager.EXTRA_STATE_RINGING -> CallType.MISSED
                        else -> CallType.ENDED
                    }

                    dispatchCallAlert(
                        context = context,
                        callId = callId,
                        callType = callType,
                        number = lastNumber
                    )

                    lastNumber = null
                    currentCallId = null
                    isOutgoing = false
                }
            }

            lastState = stateStr
        }
    }

    private fun dispatchCallAlert(
        context: Context,
        callId: String,
        callType: CallType,
        number: String?
    ) {
        val callerName = ContactsHelper.getContactName(context, number)
        val avatarBase64 = ContactsHelper.getContactPhotoBase64(context, number)

        val payload = CallPayload(
            id = callId,
            callType = callType,
            callerName = callerName,
            callerNumber = number,
            callerAvatarBase64 = avatarBase64,
            timestamp = System.currentTimeMillis()
        )

        Log.d(TAG, "Dispatching call alert: type=$callType, name=$callerName, number=$number")
        MobileServiceManager.getInstance(context).sendCall(payload)
    }
}
