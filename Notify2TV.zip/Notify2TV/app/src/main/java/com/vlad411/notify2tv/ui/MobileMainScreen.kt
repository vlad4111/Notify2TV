package com.vlad411.notify2tv.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.List
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tv
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Slider
import kotlin.math.roundToInt
import com.vlad411.notify2tv.model.BannerPosition
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.zIndex
import com.vlad411.notify2tv.network.NetworkUtils
import com.vlad411.notify2tv.network.ServerState
import com.vlad411.notify2tv.service.TvReceiverManager
import com.vlad411.notify2tv.service.TvServerService
import android.content.ClipboardManager
import android.util.Log
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.vlad411.notify2tv.model.CallPayload
import com.vlad411.notify2tv.model.CallType
import com.vlad411.notify2tv.model.NotificationPayload
import com.vlad411.notify2tv.model.PairingStatus
import com.vlad411.notify2tv.network.ClientConnectionState
import com.vlad411.notify2tv.service.ForwardingLogEntry
import com.vlad411.notify2tv.service.LogStatus
import com.vlad411.notify2tv.service.LogType
import com.vlad411.notify2tv.service.MobileServiceManager
import com.vlad411.notify2tv.ui.theme.Notify2TVTheme
import com.vlad411.notify2tv.util.DiscoveredTvDevice
import com.vlad411.notify2tv.util.NsdDiscoveryManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MobileMainScreen(
    serviceManager: MobileServiceManager? = null,
    onSwitchToTvMode: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val actualServiceManager = serviceManager ?: remember { MobileServiceManager.getInstance(context) }

    val connectionState by actualServiceManager.client.connectionState.collectAsState()
    val isForwardingEnabled by actualServiceManager.isForwardingEnabled.collectAsState()
    val pairingStatus by actualServiceManager.pairingStatus.collectAsState()
    val pairingMessage by actualServiceManager.pairingMessage.collectAsState()
    val logs by actualServiceManager.logs.collectAsState()

    val savedIp by actualServiceManager.tvIp.collectAsState()
    val savedPort by actualServiceManager.tvPort.collectAsState()
    val savedPin by actualServiceManager.tvPin.collectAsState()
    val isIgnorePersistentEnabled by actualServiceManager.isIgnorePersistentEnabled.collectAsState()
    val isExpandedCameraBannerEnabled by actualServiceManager.isExpandedCameraBannerEnabled.collectAsState()
    val bannerTimeoutSeconds by actualServiceManager.bannerTimeoutSeconds.collectAsState()

    val tvReceiverManager = remember { TvReceiverManager.getInstance(context) }
    val bannerPosition by tvReceiverManager.bannerPosition.collectAsState()
    val bannerTransparencyPercent by tvReceiverManager.bannerTransparencyPercent.collectAsState()
    val isSystemOverlayEnabled by tvReceiverManager.isSystemOverlayEnabled.collectAsState()

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME || event == Lifecycle.Event.ON_START) {
                tvReceiverManager.setAppInForeground(true)
            } else if (event == Lifecycle.Event.ON_STOP) {
                tvReceiverManager.setAppInForeground(false)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            tvReceiverManager.setAppInForeground(false)
        }
    }

    LaunchedEffect(Unit) {
        if (tvReceiverManager.serverState.value !is ServerState.Running) {
            runCatching { TvServerService.startService(context) }
        }
    }

    var inputIp by remember(savedIp) { mutableStateOf(savedIp) }
    var inputPort by remember(savedPort) { mutableStateOf(savedPort.toString()) }
    var inputPin by remember(savedPin) { mutableStateOf(savedPin) }

    var selectedTabIndex by remember { mutableIntStateOf(0) }

    val nsdManager = remember { NsdDiscoveryManager(context) }
    val discoveredDevices by nsdManager.discoveredDevices.collectAsState()
    val isSearchingTvs by nsdManager.isSearching.collectAsState()

    // Permission state checks
    var isNotificationListenerGranted by remember { mutableStateOf(isNotificationListenerEnabled(context)) }
    var missingRuntimePermissions by remember { mutableStateOf(getMissingPermissions(context)) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        missingRuntimePermissions = getMissingPermissions(context)
    }

    LaunchedEffect(Unit) {
        nsdManager.startDiscovery()
        if (savedIp.isNotBlank() && connectionState is ClientConnectionState.Disconnected) {
            actualServiceManager.connectAndPair(savedIp, savedPort, savedPin)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            nsdManager.stopDiscovery()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.PhoneAndroid,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Notify2TV Companion",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Android TV Mobile Setup",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    },
                    actions = {
                        if (onSwitchToTvMode != null) {
                            var isSwitchBtnFocused by remember { mutableStateOf(false) }
                            IconButton(
                                onClick = onSwitchToTvMode,
                                modifier = Modifier
                                    .onFocusChanged { isSwitchBtnFocused = it.isFocused }
                                    .border(
                                        width = if (isSwitchBtnFocused) 2.dp else 0.dp,
                                        color = if (isSwitchBtnFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                                        shape = CircleShape
                                    )
                                    .focusable()
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Tv,
                                    contentDescription = "Switch to TV Receiver Mode",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Header card: "Notify2TV Companion App"
                HeaderStatusCard(
                    connectionState = connectionState,
                    pairingStatus = pairingStatus,
                    isForwardingEnabled = isForwardingEnabled,
                    onToggleForwarding = { actualServiceManager.toggleForwarding(it) },
                    onDisconnect = { actualServiceManager.disconnect() }
                )

                ScrollableTabRow(
                    selectedTabIndex = selectedTabIndex,
                    edgePadding = 16.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    DPadFocusableTab(
                        selected = selectedTabIndex == 0,
                        onSelect = { selectedTabIndex = 0 },
                        text = "TV & Pairing",
                        icon = Icons.Rounded.Tv
                    )
                    DPadFocusableTab(
                        selected = selectedTabIndex == 1,
                        onSelect = {
                            selectedTabIndex = 1
                            isNotificationListenerGranted = isNotificationListenerEnabled(context)
                            missingRuntimePermissions = getMissingPermissions(context)
                        },
                        text = "Permissions",
                        icon = Icons.Rounded.Security,
                        badgeContent = {
                            if (!isNotificationListenerGranted || missingRuntimePermissions.isNotEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(MaterialTheme.colorScheme.error, CircleShape)
                                )
                            }
                        }
                    )
                    DPadFocusableTab(
                        selected = selectedTabIndex == 2,
                        onSelect = { selectedTabIndex = 2 },
                        text = "Test Alerts",
                        icon = Icons.AutoMirrored.Rounded.Send
                    )
                    DPadFocusableTab(
                        selected = selectedTabIndex == 3,
                        onSelect = { selectedTabIndex = 3 },
                        text = "Activity Log (${logs.size})",
                        icon = Icons.AutoMirrored.Rounded.List
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    when (selectedTabIndex) {
                        0 -> PairingAndTvTab(
                            isNotificationListenerGranted = isNotificationListenerGranted,
                            onOpenNotificationListenerSettings = {
                                context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                            },
                            onRefreshPermissions = {
                                isNotificationListenerGranted = isNotificationListenerEnabled(context)
                                missingRuntimePermissions = getMissingPermissions(context)
                                actualServiceManager.checkNotificationListenerPermission()
                            },
                            inputIp = inputIp,
                            onIpChange = { inputIp = it },
                            inputPort = inputPort,
                            onPortChange = { inputPort = it },
                            inputPin = inputPin,
                            onPinChange = { inputPin = it },
                            pairingMessage = pairingMessage,
                            connectionState = connectionState,
                            pairingStatus = pairingStatus,
                            discoveredDevices = discoveredDevices,
                            isSearchingTvs = isSearchingTvs,
                            isSystemOverlayEnabled = isSystemOverlayEnabled,
                            onToggleSystemOverlay = { tvReceiverManager.setSystemOverlayEnabled(it) },
                            isIgnorePersistentEnabled = isIgnorePersistentEnabled,
                            onToggleIgnorePersistent = { actualServiceManager.setIgnorePersistentEnabled(it) },
                            isExpandedCameraBannerEnabled = isExpandedCameraBannerEnabled,
                            onToggleExpandedCameraBanner = { actualServiceManager.setExpandedCameraBannerEnabled(it) },
                            bannerPosition = bannerPosition,
                            onBannerPositionChange = { pos ->
                                tvReceiverManager.setBannerPosition(pos)
                                actualServiceManager.sendBannerPosition(pos)
                            },
                            bannerTransparencyPercent = bannerTransparencyPercent,
                            onBannerTransparencyChange = { percent ->
                                tvReceiverManager.setBannerTransparencyPercent(percent)
                                actualServiceManager.setBannerTransparencyPercent(percent)
                            },
                            bannerTimeoutSeconds = bannerTimeoutSeconds,
                            onBannerTimeoutChange = { seconds ->
                                tvReceiverManager.setBannerTimeoutSeconds(seconds)
                                actualServiceManager.setBannerTimeoutSeconds(seconds)
                            },
                            onStartScan = { nsdManager.startDiscovery() },
                            onOneTapConnect = { device ->
                                inputIp = device.ip
                                inputPort = device.port.toString()
                                actualServiceManager.connectAndPair(device.ip, device.port, inputPin.ifBlank { savedPin })
                            },
                            onConnectAndPair = {
                                val portInt = inputPort.toIntOrNull() ?: NetworkUtils.DEFAULT_PORT
                                actualServiceManager.connectAndPair(inputIp.trim(), portInt, inputPin.trim())
                            },
                            onDisconnect = {
                                actualServiceManager.disconnect()
                            },
                            onPairWithUri = { ip, port, pin ->
                                inputIp = ip
                                inputPort = port.toString()
                                inputPin = pin
                                actualServiceManager.connectAndPair(ip, port, pin)
                            }
                        )
                        1 -> PermissionsTab(
                            isNotificationListenerGranted = isNotificationListenerGranted,
                            missingRuntimePermissions = missingRuntimePermissions,
                            onOpenNotificationListenerSettings = {
                                context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                            },
                            onRequestRuntimePermissions = {
                                permissionLauncher.launch(missingRuntimePermissions.toTypedArray())
                            },
                            onRefreshPermissions = {
                                isNotificationListenerGranted = isNotificationListenerEnabled(context)
                                missingRuntimePermissions = getMissingPermissions(context)
                            }
                        )
                        2 -> TestAlertsTab(
                            connectionState = connectionState,
                            isForwardingEnabled = isForwardingEnabled,
                            isSystemOverlayEnabled = isSystemOverlayEnabled,
                            onToggleSystemOverlay = { tvReceiverManager.setSystemOverlayEnabled(it) },
                            bannerPosition = bannerPosition,
                            onBannerPositionChange = { pos ->
                                tvReceiverManager.setBannerPosition(pos)
                                actualServiceManager.sendBannerPosition(pos)
                            },
                            bannerTransparencyPercent = bannerTransparencyPercent,
                            onBannerTransparencyChange = { percent ->
                                tvReceiverManager.setBannerTransparencyPercent(percent)
                                actualServiceManager.setBannerTransparencyPercent(percent)
                            },
                            bannerTimeoutSeconds = bannerTimeoutSeconds,
                            onBannerTimeoutChange = { seconds ->
                                tvReceiverManager.setBannerTimeoutSeconds(seconds)
                                actualServiceManager.setBannerTimeoutSeconds(seconds)
                            },
                            onSendTestNotification = {
                                val testPayload = NotificationPayload(
                                    id = "test_notif_${System.currentTimeMillis()}",
                                    appName = "Notify2TV Mobile",
                                    packageName = context.packageName,
                                    title = "Test Notification",
                                    body = "Hello Android TV! This is a test notification sent from your companion phone app.",
                                    timestamp = System.currentTimeMillis()
                                )

                                if (connectionState !is ClientConnectionState.Connected) {
                                    val ip = inputIp.ifBlank { savedIp }
                                    val portInt = inputPort.toIntOrNull() ?: NetworkUtils.DEFAULT_PORT
                                    val pin = inputPin.ifBlank { savedPin }
                                    if (ip.isNotBlank()) {
                                        actualServiceManager.connectAndPair(ip, portInt, pin)
                                    }
                                }
                                actualServiceManager.sendNotification(testPayload)
                                Toast.makeText(context, "Test Notification sent to TV!", Toast.LENGTH_SHORT).show()
                            },
                            onSendTestCall = {
                                val testCall = CallPayload(
                                    id = "test_call_${System.currentTimeMillis()}",
                                    callType = CallType.INCOMING,
                                    callerName = "John Doe (Test Call)",
                                    callerNumber = "+1 (555) 019-2831",
                                    timestamp = System.currentTimeMillis()
                                )

                                if (connectionState !is ClientConnectionState.Connected) {
                                    val ip = inputIp.ifBlank { savedIp }
                                    val portInt = inputPort.toIntOrNull() ?: NetworkUtils.DEFAULT_PORT
                                    val pin = inputPin.ifBlank { savedPin }
                                    if (ip.isNotBlank()) {
                                        actualServiceManager.connectAndPair(ip, portInt, pin)
                                    }
                                }
                                actualServiceManager.sendCall(testCall)
                                Toast.makeText(context, "Test Call Alert sent to TV!", Toast.LENGTH_SHORT).show()
                            },
                            onSendTestCameraNotification = {
                                if (connectionState !is ClientConnectionState.Connected) {
                                    val ip = inputIp.ifBlank { savedIp }
                                    val portInt = inputPort.toIntOrNull() ?: NetworkUtils.DEFAULT_PORT
                                    val pin = inputPin.ifBlank { savedPin }
                                    if (ip.isNotBlank()) {
                                        actualServiceManager.connectAndPair(ip, portInt, pin)
                                    }
                                }
                                actualServiceManager.sendTestCameraNotification()
                                Toast.makeText(context, "Test Security Camera Alert sent to TV!", Toast.LENGTH_SHORT).show()
                            }
                        )
                        3 -> ForwardingLogsTab(
                            logs = logs,
                            onClearLogs = { actualServiceManager.clearLogs() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DPadFocusableTab(
    selected: Boolean,
    onSelect: () -> Unit,
    text: String,
    icon: ImageVector,
    badgeContent: (@Composable () -> Unit)? = null
) {
    var isFocused by remember { mutableStateOf(false) }

    Tab(
        selected = selected,
        onClick = onSelect,
        modifier = Modifier
            .padding(horizontal = 4.dp, vertical = 4.dp)
            .onFocusChanged { state ->
                isFocused = state.isFocused
                if (state.isFocused) {
                    onSelect()
                }
            }
            .border(
                width = if (isFocused) 2.dp else 0.dp,
                color = if (isFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .background(
                color = if (isFocused) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                else if (selected) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.2f)
                else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .focusable()
            .onKeyEvent { keyEvent ->
                if (keyEvent.type == KeyEventType.KeyUp &&
                    (keyEvent.key == Key.DirectionCenter || keyEvent.key == Key.Enter || keyEvent.key == Key.NumPadEnter)
                ) {
                    onSelect()
                    true
                } else {
                    false
                }
            },
        text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = text,
                    fontWeight = if (selected || isFocused) FontWeight.Bold else FontWeight.Normal,
                    color = if (isFocused || selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                )
                if (badgeContent != null) {
                    Spacer(modifier = Modifier.width(6.dp))
                    badgeContent()
                }
            }
        },
        icon = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = if (isFocused || selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    )
}

@Composable
private fun HeaderStatusCard(
    connectionState: ClientConnectionState,
    pairingStatus: PairingStatus,
    isForwardingEnabled: Boolean,
    onToggleForwarding: (Boolean) -> Unit,
    onDisconnect: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Notify2TV Companion App",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val (statusColor, statusText) = when (connectionState) {
                        is ClientConnectionState.Connected -> {
                            if (pairingStatus == PairingStatus.ACCEPTED) {
                                Pair(Color(0xFF4CAF50), "Connected to TV")
                            } else {
                                Pair(Color(0xFFFF9800), "Connected (Pairing Pending)")
                            }
                        }
                        is ClientConnectionState.Connecting -> Pair(
                            Color(0xFF2196F3),
                            "Connecting to TV..."
                        )
                        is ClientConnectionState.Error -> Pair(
                            MaterialTheme.colorScheme.error,
                            "Connection Error"
                        )
                        is ClientConnectionState.Disconnected -> Pair(
                            MaterialTheme.colorScheme.outline,
                            "Disconnected"
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .background(statusColor, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold
                        )
                        if (connectionState is ClientConnectionState.Connected) {
                            Text(
                                text = "TV Address: ${connectionState.hostIp}:${connectionState.port}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            Text(
                                text = "No TV Paired / Connected",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                if (connectionState is ClientConnectionState.Connected) {
                    var isDisconnectFocused by remember { mutableStateOf(false) }
                    OutlinedButton(
                        onClick = onDisconnect,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .onFocusChanged { isDisconnectFocused = it.isFocused }
                            .border(
                                width = if (isDisconnectFocused) 2.dp else 0.dp,
                                color = if (isDisconnectFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .focusable()
                    ) {
                        Text("Disconnect")
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            var isForwardingRowFocused by remember { mutableStateOf(false) }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .onFocusChanged { isForwardingRowFocused = it.isFocused }
                    .border(
                        width = if (isForwardingRowFocused) 2.dp else 0.dp,
                        color = if (isForwardingRowFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .clickable { onToggleForwarding(!isForwardingEnabled) }
                    .background(MaterialTheme.colorScheme.surfaceContainer)
                    .padding(horizontal = 14.dp, vertical = 10.dp)
                    .focusable(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Notification Forwarding Service",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = if (isForwardingEnabled) "Active - forwarding to TV" else "Paused - service disabled",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Switch(
                    checked = isForwardingEnabled,
                    onCheckedChange = onToggleForwarding
                )
            }
        }
    }
}

@Composable
private fun NotificationListenerStatusCard(
    isNotificationListenerGranted: Boolean,
    onOpenNotificationListenerSettings: () -> Unit,
    onRefreshStatus: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = if (isNotificationListenerGranted)
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
            else
                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.65f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Rounded.Notifications,
                        contentDescription = null,
                        tint = if (isNotificationListenerGranted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Notification Access Permission",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Required to forward phone push notifications to TV",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isNotificationListenerGranted) Color(0xFF2E7D32) else Color(0xFFC62828)
                ) {
                    Text(
                        text = if (isNotificationListenerGranted) "REQUIRED FOR FORWARDING: GRANTED" else "REQUIRED FOR FORWARDING: MISSING",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Check Notification Listener Service Status indicator
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            imageVector = if (isNotificationListenerGranted) Icons.Rounded.CheckCircle else Icons.Rounded.Warning,
                            contentDescription = null,
                            tint = if (isNotificationListenerGranted) Color(0xFF2E7D32) else Color(0xFFC62828),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Check Notification Listener Service Status",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (isNotificationListenerGranted) "ACTIVE (Android OS enabled TvNotificationListenerService)" else "INACTIVE (Android OS has not enabled listener service)",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isNotificationListenerGranted) Color(0xFF2E7D32) else Color(0xFFC62828)
                            )
                        }
                    }

                    var isCheckBtnFocused by remember { mutableStateOf(false) }
                    IconButton(
                        onClick = onRefreshStatus,
                        modifier = Modifier
                            .onFocusChanged { isCheckBtnFocused = it.isFocused }
                            .border(
                                width = if (isCheckBtnFocused) 2.dp else 0.dp,
                                color = if (isCheckBtnFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape = CircleShape
                            )
                            .focusable()
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Check Status",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            if (!isNotificationListenerGranted) {
                Spacer(modifier = Modifier.height(12.dp))
                var isSettingsBtnFocused by remember { mutableStateOf(false) }
                Button(
                    onClick = onOpenNotificationListenerSettings,
                    modifier = Modifier
                        .fillMaxWidth()
                        .onFocusChanged { isSettingsBtnFocused = it.isFocused }
                        .border(
                            width = if (isSettingsBtnFocused) 2.dp else 0.dp,
                            color = if (isSettingsBtnFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                            shape = RoundedCornerShape(20.dp)
                        )
                        .focusable(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Icon(imageVector = Icons.Rounded.Settings, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Enable Notification Access in Settings")
                }
            }
        }
    }
}

private fun parsePairingCode(rawInput: String): Triple<String, Int, String>? {
    val input = rawInput.trim()
    if (input.isBlank()) return null
    try {
        var ip = ""
        var port = NetworkUtils.DEFAULT_PORT
        var pin = ""

        if (input.contains("ip=")) {
            val match = Regex("ip=([^&]+)").find(input)
            if (match != null) ip = match.groupValues[1]
        }
        if (input.contains("port=")) {
            val match = Regex("port=([^&]+)").find(input)
            if (match != null) port = match.groupValues[1].toIntOrNull() ?: NetworkUtils.DEFAULT_PORT
        }
        if (input.contains("pin=")) {
            val match = Regex("pin=([^&]+)").find(input)
            if (match != null) pin = match.groupValues[1]
        }

        if (ip.isBlank()) {
            val hostPortMatch = Regex("notify2tv://([^:/]+)(?::(\\d+))?").find(input)
            if (hostPortMatch != null) {
                val host = hostPortMatch.groupValues[1]
                if (host != "pair") ip = host
                val matchedPort = hostPortMatch.groupValues[2]
                if (matchedPort.isNotBlank()) {
                    port = matchedPort.toIntOrNull() ?: NetworkUtils.DEFAULT_PORT
                }
            }
        }

        if (ip.isBlank()) {
            val ipMatch = Regex("(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3})").find(input)
            if (ipMatch != null) ip = ipMatch.value
        }

        if (ip.isNotBlank()) {
            return Triple(ip, port, pin)
        }
    } catch (e: Exception) {
        Log.e("PairingParser", "Failed to parse pairing string: $rawInput", e)
    }
    return null
}

@Composable
private fun PairingAndTvTab(
    isNotificationListenerGranted: Boolean,
    onOpenNotificationListenerSettings: () -> Unit,
    onRefreshPermissions: () -> Unit,
    inputIp: String,
    onIpChange: (String) -> Unit,
    inputPort: String,
    onPortChange: (String) -> Unit,
    inputPin: String,
    onPinChange: (String) -> Unit,
    pairingMessage: String?,
    connectionState: ClientConnectionState,
    pairingStatus: PairingStatus,
    discoveredDevices: List<DiscoveredTvDevice>,
    isSearchingTvs: Boolean,
    isSystemOverlayEnabled: Boolean,
    onToggleSystemOverlay: (Boolean) -> Unit,
    isIgnorePersistentEnabled: Boolean,
    onToggleIgnorePersistent: (Boolean) -> Unit,
    isExpandedCameraBannerEnabled: Boolean,
    onToggleExpandedCameraBanner: (Boolean) -> Unit,
    bannerPosition: BannerPosition,
    onBannerPositionChange: (BannerPosition) -> Unit,
    bannerTransparencyPercent: Int,
    onBannerTransparencyChange: (Int) -> Unit,
    bannerTimeoutSeconds: Int,
    onBannerTimeoutChange: (Int) -> Unit,
    onStartScan: () -> Unit,
    onOneTapConnect: (DiscoveredTvDevice) -> Unit,
    onConnectAndPair: () -> Unit,
    onDisconnect: () -> Unit,
    onPairWithUri: (String, Int, String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            NotificationListenerStatusCard(
                isNotificationListenerGranted = isNotificationListenerGranted,
                onOpenNotificationListenerSettings = onOpenNotificationListenerSettings,
                onRefreshStatus = onRefreshPermissions
            )
        }

        if (connectionState is ClientConnectionState.Connected) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = null,
                                    tint = Color(0xFF4CAF50),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = if (pairingStatus == PairingStatus.ACCEPTED) "Connected & Paired with TV" else "Connected to TV (Pending Pairing)",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                    Text(
                                        text = if (inputIp.isNotBlank()) "$inputIp:$inputPort" else "Active Connection",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                    )
                                }
                            }
                            OutlinedButton(
                                onClick = onDisconnect,
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                Text("Disconnect")
                            }
                        }
                    }
                }
            }
        }

        item {
            // Auto Discovery Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Search,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "TV Auto-Discovery",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = onStartScan,
                            enabled = !isSearchingTvs
                        ) {
                            if (isSearchingTvs) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Scanning...")
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Scan Network")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (discoveredDevices.isEmpty()) {
                        Text(
                            text = if (isSearchingTvs) "Scanning local Wi-Fi for Android TV..." else "No TV detected automatically. Ensure phone and TV are on the same Wi-Fi network or use manual entry below.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            discoveredDevices.forEach { device ->
                                ElevatedCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.elevatedCardColors(
                                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                                    )
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Rounded.Tv,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                                modifier = Modifier.size(28.dp)
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "📺 Discovered Android TV (${device.ip})",
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                                )
                                                Text(
                                                    text = "Service: ${device.name} • Port: ${device.port}",
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        Button(
                                            onClick = { onOneTapConnect(device) },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(48.dp),
                                            shape = RoundedCornerShape(24.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.TouchApp,
                                                contentDescription = null
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "One-Tap Connect & Pair",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            var isManualExpanded by remember { mutableStateOf(false) }
            var showQrDialog by remember { mutableStateOf(false) }
            var qrDialogInput by remember { mutableStateOf("") }
            val context = LocalContext.current

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isManualExpanded = !isManualExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Settings,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Advanced Manual IP / PIN Entry",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Icon(
                            imageVector = if (isManualExpanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                            contentDescription = null
                        )
                    }

                    AnimatedVisibility(visible = isManualExpanded) {
                        Column {
                            Spacer(modifier = Modifier.height(16.dp))

                            // Paste QR Pairing Code / Scan button
                            Button(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                    val clipText = clipboard?.primaryClip?.getItemAt(0)?.text?.toString()
                                    val parsed = if (!clipText.isNullOrBlank()) parsePairingCode(clipText) else null

                                    if (parsed != null) {
                                        onPairWithUri(parsed.first, parsed.second, parsed.third)
                                        Toast.makeText(context, "Pairing URI detected! Connecting to TV at ${parsed.first}...", Toast.LENGTH_SHORT).show()
                                    } else {
                                        qrDialogInput = clipText ?: ""
                                        showQrDialog = true
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.secondary
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                shape = RoundedCornerShape(24.dp)
                            ) {
                                Icon(imageVector = Icons.Rounded.QrCodeScanner, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Paste QR Pairing Code / Scan")
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            OutlinedTextField(
                                value = inputIp,
                                onValueChange = onIpChange,
                                label = { Text("TV IP Address") },
                                placeholder = { Text("e.g. 192.168.1.100") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(modifier = Modifier.fillMaxWidth()) {
                                OutlinedTextField(
                                    value = inputPort,
                                    onValueChange = onPortChange,
                                    label = { Text("Port") },
                                    placeholder = { Text("8080") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f)
                                )

                                Spacer(modifier = Modifier.width(12.dp))

                                OutlinedTextField(
                                    value = inputPin,
                                    onValueChange = onPinChange,
                                    label = { Text("Pairing PIN Code") },
                                    placeholder = { Text("4-digit PIN") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1.5f)
                                )
                            }

                            if (!pairingMessage.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.errorContainer
                                ) {
                                    Text(
                                        text = pairingMessage,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = onConnectAndPair,
                                enabled = inputIp.isNotBlank() && connectionState !is ClientConnectionState.Connecting,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp),
                                shape = RoundedCornerShape(25.dp)
                            ) {
                                if (connectionState is ClientConnectionState.Connecting) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Connecting...")
                                } else {
                                    Icon(imageVector = Icons.Rounded.Link, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Connect & Pair with TV")
                                }
                            }
                        }
                    }
                }
            }

            if (showQrDialog) {
                AlertDialog(
                    onDismissRequest = { showQrDialog = false },
                    title = { Text("Paste QR Pairing Code / URI") },
                    text = {
                        Column {
                            Text(
                                text = "Enter or paste pairing code string (e.g., notify2tv://pair?ip=192.168.1.100&port=8080&pin=1234):",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = qrDialogInput,
                                onValueChange = { qrDialogInput = it },
                                placeholder = { Text("notify2tv://pair?ip=...") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                val parsed = parsePairingCode(qrDialogInput)
                                if (parsed != null) {
                                    onPairWithUri(parsed.first, parsed.second, parsed.third)
                                    showQrDialog = false
                                    Toast.makeText(context, "Connecting to TV at ${parsed.first}...", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Invalid Pairing URI/IP format", Toast.LENGTH_SHORT).show()
                                }
                            }
                        ) {
                            Text("Pair Instantly")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showQrDialog = false }) {
                            Text("Cancel")
                        }
                    }
                )
            }
        }

        item {
            MobileSystemOverlaySettingCard(
                isSystemOverlayEnabled = isSystemOverlayEnabled,
                onToggleSystemOverlay = onToggleSystemOverlay
            )
        }

        item {
            MobileIgnorePersistentSettingCard(
                isIgnorePersistentEnabled = isIgnorePersistentEnabled,
                onToggleIgnorePersistent = onToggleIgnorePersistent
            )
        }

        item {
            MobileCameraBannerSettingCard(
                isExpandedCameraBannerEnabled = isExpandedCameraBannerEnabled,
                onToggleExpandedCameraBanner = onToggleExpandedCameraBanner
            )
        }

        item {
            MobileBannerPositionCard(
                bannerPosition = bannerPosition,
                onBannerPositionChange = onBannerPositionChange
            )
        }

        item {
            MobileBannerTransparencyCard(
                bannerTransparencyPercent = bannerTransparencyPercent,
                onBannerTransparencyChange = onBannerTransparencyChange
            )
        }

        item {
            MobileBannerTimeoutCard(
                bannerTimeoutSeconds = bannerTimeoutSeconds,
                onBannerTimeoutChange = onBannerTimeoutChange
            )
        }
    }
}

@Composable
private fun PermissionsTab(
    isNotificationListenerGranted: Boolean,
    missingRuntimePermissions: List<String>,
    onOpenNotificationListenerSettings: () -> Unit,
    onRequestRuntimePermissions: () -> Unit,
    onRefreshPermissions: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            NotificationListenerStatusCard(
                isNotificationListenerGranted = isNotificationListenerGranted,
                onOpenNotificationListenerSettings = onOpenNotificationListenerSettings,
                onRefreshStatus = onRefreshPermissions
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Security,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Required System Permissions",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        var isRefreshBtnFocused by remember { mutableStateOf(false) }
                        IconButton(
                            onClick = onRefreshPermissions,
                            modifier = Modifier
                                .onFocusChanged { isRefreshBtnFocused = it.isFocused }
                                .border(
                                    width = if (isRefreshBtnFocused) 2.dp else 0.dp,
                                    color = if (isRefreshBtnFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    shape = CircleShape
                                )
                                .focusable()
                        ) {
                            Icon(imageVector = Icons.Rounded.Refresh, contentDescription = "Refresh")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Notification Listener Permission Item
                    PermissionItemCard(
                        title = "Notification Listener Service",
                        description = "Required to intercept incoming notifications and forward app icons/pictures to Android TV",
                        isGranted = isNotificationListenerGranted,
                        icon = Icons.Rounded.Notifications,
                        actionLabel = "Enable in System Settings",
                        onAction = onOpenNotificationListenerSettings
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Telephony & Phone Call Permissions Item
                    val phoneStateGranted = !missingRuntimePermissions.contains(Manifest.permission.READ_PHONE_STATE)
                    val callLogGranted = !missingRuntimePermissions.contains(Manifest.permission.READ_CALL_LOG)
                    val contactsGranted = !missingRuntimePermissions.contains(Manifest.permission.READ_CONTACTS)
                    val allPhoneGranted = phoneStateGranted && callLogGranted && contactsGranted

                    PermissionItemCard(
                        title = "Phone Call & Contact Access",
                        description = "Required to capture incoming/outgoing call alerts and resolve caller names & photos",
                        isGranted = allPhoneGranted,
                        icon = Icons.Rounded.Phone,
                        actionLabel = "Grant Permissions",
                        onAction = onRequestRuntimePermissions
                    )
                }
            }
        }
    }
}

@Composable
private fun PermissionItemCard(
    title: String,
    description: String,
    isGranted: Boolean,
    icon: ImageVector,
    actionLabel: String,
    onAction: () -> Unit
) {
    var isCardFocused by remember { mutableStateOf(false) }
    var isBtnFocused by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { isCardFocused = it.isFocused }
            .border(
                width = if (isCardFocused || isBtnFocused) 2.dp else 0.dp,
                color = if (isCardFocused || isBtnFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .focusable(),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceContainer
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isGranted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isGranted) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isGranted) Icons.Rounded.CheckCircle else Icons.Rounded.Warning,
                            contentDescription = null,
                            tint = if (isGranted) Color(0xFF2E7D32) else Color(0xFFC62828),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isGranted) "Granted" else "Missing",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isGranted) Color(0xFF2E7D32) else Color(0xFFC62828)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (!isGranted) {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onAction,
                    modifier = Modifier
                        .fillMaxWidth()
                        .onFocusChanged { isBtnFocused = it.isFocused }
                        .border(
                            width = if (isBtnFocused) 2.dp else 0.dp,
                            color = if (isBtnFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                            shape = RoundedCornerShape(20.dp)
                        )
                        .focusable()
                ) {
                    Text(actionLabel)
                }
            }
        }
    }
}

@Composable
private fun TestAlertsTab(
    connectionState: ClientConnectionState,
    isForwardingEnabled: Boolean,
    isSystemOverlayEnabled: Boolean,
    onToggleSystemOverlay: (Boolean) -> Unit,
    bannerPosition: BannerPosition,
    onBannerPositionChange: (BannerPosition) -> Unit,
    bannerTransparencyPercent: Int,
    onBannerTransparencyChange: (Int) -> Unit,
    bannerTimeoutSeconds: Int,
    onBannerTimeoutChange: (Int) -> Unit,
    onSendTestNotification: () -> Unit,
    onSendTestCall: () -> Unit,
    onSendTestCameraNotification: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            MobileSystemOverlaySettingCard(
                isSystemOverlayEnabled = isSystemOverlayEnabled,
                onToggleSystemOverlay = onToggleSystemOverlay
            )
        }

        item {
            MobileBannerPositionCard(
                bannerPosition = bannerPosition,
                onBannerPositionChange = onBannerPositionChange
            )
        }

        item {
            MobileBannerTransparencyCard(
                bannerTransparencyPercent = bannerTransparencyPercent,
                onBannerTransparencyChange = onBannerTransparencyChange
            )
        }

        item {
            MobileBannerTimeoutCard(
                bannerTimeoutSeconds = bannerTimeoutSeconds,
                onBannerTimeoutChange = onBannerTimeoutChange
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Test Alerts Sender",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Trigger test alerts directly from this companion phone app to verify TV overlay popups and connection.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    if (!isForwardingEnabled) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Warning,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Forwarding Service is currently Paused in Header card. Enable forwarding above to send alerts.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    if (connectionState !is ClientConnectionState.Connected) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Info,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Not connected to TV. Connect and pair with TV first to send alerts.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    var isNotifBtnFocused by remember { mutableStateOf(false) }
                    Button(
                        onClick = onSendTestNotification,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .onFocusChanged { isNotifBtnFocused = it.isFocused }
                            .border(
                                width = if (isNotifBtnFocused) 2.dp else 0.dp,
                                color = if (isNotifBtnFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape = RoundedCornerShape(24.dp)
                            )
                            .focusable()
                    ) {
                        Icon(imageVector = Icons.Rounded.Notifications, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Send Test Notification")
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    var isCallBtnFocused by remember { mutableStateOf(false) }
                    Button(
                        onClick = onSendTestCall,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .onFocusChanged { isCallBtnFocused = it.isFocused }
                            .border(
                                width = if (isCallBtnFocused) 2.dp else 0.dp,
                                color = if (isCallBtnFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape = RoundedCornerShape(24.dp)
                            )
                            .focusable()
                    ) {
                        Icon(imageVector = Icons.Rounded.Call, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Send Test Call Alert")
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    var isCamBtnFocused by remember { mutableStateOf(false) }
                    Button(
                        onClick = onSendTestCameraNotification,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFD50000)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .onFocusChanged { isCamBtnFocused = it.isFocused }
                            .border(
                                width = if (isCamBtnFocused) 2.dp else 0.dp,
                                color = if (isCamBtnFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape = RoundedCornerShape(24.dp)
                            )
                            .focusable()
                    ) {
                        Icon(imageVector = Icons.Rounded.Videocam, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Test Security Camera Alert")
                    }
                }
            }
        }
    }
}

@Composable
private fun ForwardingLogsTab(
    logs: List<ForwardingLogEntry>,
    onClearLogs: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Live Forwarding Activity",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            if (logs.isNotEmpty()) {
                var isClearBtnFocused by remember { mutableStateOf(false) }
                IconButton(
                    onClick = onClearLogs,
                    modifier = Modifier
                        .onFocusChanged { isClearBtnFocused = it.isFocused }
                        .border(
                            width = if (isClearBtnFocused) 2.dp else 0.dp,
                            color = if (isClearBtnFocused) MaterialTheme.colorScheme.error else Color.Transparent,
                            shape = CircleShape
                        )
                        .focusable()
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Delete,
                        contentDescription = "Clear Logs",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (logs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No forwarding logs yet. Alerts sent to TV will appear here.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(logs, key = { it.id }) { log ->
                    LogEntryCard(log = log)
                }
            }
        }
    }
}

@Composable
private fun LogEntryCard(log: ForwardingLogEntry) {
    val dateFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    val formattedTime = remember(log.timestamp) { dateFormat.format(Date(log.timestamp)) }

    val (icon, badgeColor) = when (log.type) {
        LogType.NOTIFICATION -> Pair(Icons.Rounded.Notifications, MaterialTheme.colorScheme.primary)
        LogType.CALL -> Pair(Icons.Rounded.Phone, Color(0xFFE91E63))
        LogType.PAIRING -> Pair(Icons.Rounded.Link, Color(0xFFFF9800))
        LogType.SYSTEM -> Pair(Icons.Rounded.Info, MaterialTheme.colorScheme.secondary)
    }

    val statusColor = when (log.status) {
        LogStatus.SENT -> Color(0xFF4CAF50)
        LogStatus.RECEIVED -> Color(0xFF2196F3)
        LogStatus.FAILED -> MaterialTheme.colorScheme.error
        LogStatus.INFO -> MaterialTheme.colorScheme.outline
    }

    var isCardFocused by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { isCardFocused = it.isFocused }
            .border(
                width = if (isCardFocused) 2.dp else 0.dp,
                color = if (isCardFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .focusable(),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(badgeColor.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = badgeColor,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = log.title,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = formattedTime,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = log.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(statusColor, CircleShape)
            )
        }
    }
}

private fun isNotificationListenerEnabled(context: Context): Boolean {
    return runCatching {
        val enabledPackages = NotificationManagerCompat.getEnabledListenerPackages(context)
        enabledPackages.contains(context.packageName)
    }.getOrDefault(false)
}

private fun getMissingPermissions(context: Context): List<String> {
    return runCatching {
        val required = mutableListOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            required.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        required.filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
    }.getOrDefault(emptyList())
}

@Composable
private fun MobileSystemOverlaySettingCard(
    isSystemOverlayEnabled: Boolean,
    onToggleSystemOverlay: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "System Overlay Window",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Show over other TV apps when in background",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Switch(
                checked = isSystemOverlayEnabled,
                onCheckedChange = onToggleSystemOverlay
            )
        }
    }
}

@Composable
private fun MobileIgnorePersistentSettingCard(
    isIgnorePersistentEnabled: Boolean,
    onToggleIgnorePersistent: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Ignore Persistent / Ongoing Notifications",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Filter out media players, step counters, VPN indicators, and background service notifications from forwarding to TV",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Switch(
                checked = isIgnorePersistentEnabled,
                onCheckedChange = onToggleIgnorePersistent
            )
        }
    }
}

@Composable
private fun MobileCameraBannerSettingCard(
    isExpandedCameraBannerEnabled: Boolean,
    onToggleExpandedCameraBanner: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Large Security Camera Image Banner",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Show expanded full-screen image banner after camera notifications",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Switch(
                checked = isExpandedCameraBannerEnabled,
                onCheckedChange = onToggleExpandedCameraBanner
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MobileBannerPositionCard(
    bannerPosition: BannerPosition,
    onBannerPositionChange: (BannerPosition) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "TV Banner Position",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Select screen corner for overlay notification banners on TV:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BannerPosition.entries.forEach { position ->
                    val isSelected = position == bannerPosition
                    var isFocused by remember { mutableStateOf(false) }

                    FilterChip(
                        selected = isSelected,
                        onClick = { onBannerPositionChange(position) },
                        label = {
                            Text(
                                text = position.displayName,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        leadingIcon = if (isSelected) {
                            {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        } else null,
                        modifier = Modifier
                            .weight(1f)
                            .onFocusChanged { isFocused = it.isFocused }
                            .border(
                                width = if (isFocused) 2.dp else 0.dp,
                                color = if (isFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .focusable()
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MobileBannerTransparencyCard(
    bannerTransparencyPercent: Int,
    onBannerTransparencyChange: (Int) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Banner Transparency",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "$bannerTransparencyPercent%",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Adjust notification banner transparency on TV (0% = opaque, 100% = transparent):",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        val newPct = (bannerTransparencyPercent - 10).coerceIn(0, 100)
                        onBannerTransparencyChange(newPct)
                    },
                    enabled = bannerTransparencyPercent > 0,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("-10%", fontWeight = FontWeight.Bold)
                }

                Slider(
                    value = bannerTransparencyPercent.toFloat(),
                    onValueChange = { newValue ->
                        val rounded = (newValue / 10f).roundToInt() * 10
                        onBannerTransparencyChange(rounded.coerceIn(0, 100))
                    },
                    valueRange = 0f..100f,
                    steps = 9,
                    modifier = Modifier.weight(1f)
                )

                OutlinedButton(
                    onClick = {
                        val newPct = (bannerTransparencyPercent + 10).coerceIn(0, 100)
                        onBannerTransparencyChange(newPct)
                    },
                    enabled = bannerTransparencyPercent < 100,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("+10%", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(0, 10, 20, 30, 50, 70, 100).forEach { preset ->
                    val isSelected = preset == bannerTransparencyPercent
                    FilterChip(
                        selected = isSelected,
                        onClick = { onBannerTransparencyChange(preset) },
                        label = {
                            Text(
                                text = "$preset%",
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        leadingIcon = if (isSelected) {
                            {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        } else null,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MobileBannerTimeoutCard(
    bannerTimeoutSeconds: Int,
    onBannerTimeoutChange: (Int) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Auto-Dismiss Timeout: $bannerTimeoutSeconds Seconds",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Select how long notification banners stay on screen before auto-dismissing:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(3, 5, 7, 10).forEach { seconds ->
                    val isSelected = seconds == bannerTimeoutSeconds
                    var isFocused by remember { mutableStateOf(false) }

                    FilterChip(
                        selected = isSelected,
                        onClick = { onBannerTimeoutChange(seconds) },
                        label = {
                            Text(
                                text = "$seconds Seconds",
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        leadingIcon = if (isSelected) {
                            {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        } else null,
                        modifier = Modifier
                            .weight(1f)
                            .onFocusChanged { isFocused = it.isFocused }
                            .border(
                                width = if (isFocused) 2.dp else 0.dp,
                                color = if (isFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .focusable()
                    )
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MobileMainScreenPreview() {
    Notify2TVTheme {
        MobileMainScreen()
    }
}
