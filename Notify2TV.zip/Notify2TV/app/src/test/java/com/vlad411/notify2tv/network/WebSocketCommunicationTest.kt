package com.vlad411.notify2tv.network

import com.vlad411.notify2tv.model.ClientType
import com.vlad411.notify2tv.model.NetworkMessage
import com.vlad411.notify2tv.model.NotificationPayload
import com.vlad411.notify2tv.model.PairingPayload
import com.vlad411.notify2tv.model.PairingStatus
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class WebSocketCommunicationTest {

    private val testPort = 8888
    private lateinit var server: TvWebSocketServer
    private lateinit var client: MobileWebSocketClient

    @Before
    fun setUp() {
        server = TvWebSocketServer(port = testPort)
        client = MobileWebSocketClient()
    }

    @After
    fun tearDown() {
        client.disconnect()
        server.stop()
    }

    @Test
    fun testServerClientConnectionAndMessaging(): Unit = runBlocking {
        server.start()

        // Wait for server to start
        withTimeout(5000) {
            server.serverState.first { it is ServerState.Running }
        }

        client.connect(hostIp = "127.0.0.1", port = testPort)

        // Wait for client to connect and server to record session
        withTimeout(5000) {
            client.connectionState.first { it is ClientConnectionState.Connected }
            server.connectedClientsCount.first { it > 0 }
        }

        val pairingPayload = PairingPayload(
            pairingCode = "654321",
            ip = "127.0.0.1",
            port = testPort,
            deviceId = "mobile-1",
            deviceName = "My Phone",
            clientType = ClientType.MOBILE,
            status = PairingStatus.PENDING
        )

        val sendSuccess = client.sendMessage(NetworkMessage.PairingRequest(pairingPayload))
        assertTrue(sendSuccess)

        val receivedMessage = withTimeout(5000) {
            server.incomingMessages.first()
        }

        assertTrue(receivedMessage is NetworkMessage.PairingRequest)
        val request = receivedMessage as NetworkMessage.PairingRequest
        assertEquals("654321", request.payload.pairingCode)
        assertEquals("My Phone", request.payload.deviceName)

        // Server broadcasts a notification back to client
        val notificationPayload = NotificationPayload(
            id = "notif-999",
            appName = "System",
            packageName = "android",
            title = "Connected",
            body = "Device paired successfully"
        )
        server.broadcastMessage(NetworkMessage.Notification(notificationPayload))

        val clientReceivedMessage = withTimeout(5000) {
            client.incomingMessages.first()
        }

        assertTrue(clientReceivedMessage is NetworkMessage.Notification)
        val notif = clientReceivedMessage as NetworkMessage.Notification
        assertEquals("notif-999", notif.payload.id)
        assertEquals("Device paired successfully", notif.payload.body)

        // Test sending BannerTransparencyUpdate from client to server
        val transparencyDeferred = async {
            withTimeout(5000) {
                server.incomingMessages.first { it is NetworkMessage.BannerTransparencyUpdate }
            }
        }

        val transparencyMsg = NetworkMessage.BannerTransparencyUpdate(percent = 30)
        val sendTransparencySuccess = client.sendMessage(transparencyMsg)
        assertTrue(sendTransparencySuccess)

        val serverReceivedTransparency = transparencyDeferred.await() as NetworkMessage.BannerTransparencyUpdate
        assertEquals(30, serverReceivedTransparency.percent)

        // Test sending BannerTimeoutUpdate from client to server
        val timeoutDeferred = async {
            withTimeout(5000) {
                server.incomingMessages.first { it is NetworkMessage.BannerTimeoutUpdate }
            }
        }

        val timeoutMsg = NetworkMessage.BannerTimeoutUpdate(seconds = 10)
        val sendTimeoutSuccess = client.sendMessage(timeoutMsg)
        assertTrue(sendTimeoutSuccess)

        val serverReceivedTimeout = timeoutDeferred.await() as NetworkMessage.BannerTimeoutUpdate
        assertEquals(10, serverReceivedTimeout.seconds)
    }
}
