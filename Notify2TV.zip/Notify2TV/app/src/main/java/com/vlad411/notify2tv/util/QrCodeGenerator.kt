package com.vlad411.notify2tv.util

import android.graphics.Bitmap
import android.graphics.Color

/**
 * Pure Kotlin QR Code generator supporting Byte mode and Level M error correction.
 */
object QrCodeGenerator {

    private data class VersionSpec(
        val version: Int,
        val dimension: Int,
        val dataCapacityBytes: Int,
        val ecCodewords: Int,
        val alignPos: IntArray
    )

    private val VERSIONS = arrayOf(
        VersionSpec(1, 21, 14, 10, intArrayOf()),
        VersionSpec(2, 25, 26, 16, intArrayOf(6, 18)),
        VersionSpec(3, 29, 42, 26, intArrayOf(6, 22)),
        VersionSpec(4, 33, 62, 36, intArrayOf(6, 26)),
        VersionSpec(5, 37, 84, 48, intArrayOf(6, 30))
    )

    fun generateQrCodeBitmap(
        content: String,
        size: Int = 512,
        foregroundColor: Int = Color.BLACK,
        backgroundColor: Int = Color.WHITE
    ): Bitmap {
        val bytes = content.toByteArray(Charsets.UTF_8)
        val spec = VERSIONS.firstOrNull { it.dataCapacityBytes >= bytes.size }
            ?: VERSIONS.last()

        val matrix = createQrMatrix(bytes, spec)
        val matrixSize = matrix.size
        val padding = 4
        val totalModules = matrixSize + padding * 2

        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvasPixels = IntArray(size * size)

        val moduleSize = size.toFloat() / totalModules.toFloat()

        for (y in 0 until size) {
            val moduleY = (y / moduleSize).toInt() - padding
            for (x in 0 until size) {
                val moduleX = (x / moduleSize).toInt() - padding
                val isDark = if (moduleY in 0 until matrixSize && moduleX in 0 until matrixSize) {
                    matrix[moduleY][moduleX]
                } else {
                    false
                }
                canvasPixels[y * size + x] = if (isDark) foregroundColor else backgroundColor
            }
        }

        bitmap.setPixels(canvasPixels, 0, size, 0, 0, size, size)
        return bitmap
    }

    private fun createQrMatrix(bytes: ByteArray, spec: VersionSpec): Array<BooleanArray> {
        val dim = spec.dimension
        val matrix = Array(dim) { BooleanArray(dim) }
        val reserved = Array(dim) { BooleanArray(dim) }

        // 1. Place finder patterns
        placeFinderPattern(matrix, reserved, 0, 0)
        placeFinderPattern(matrix, reserved, dim - 7, 0)
        placeFinderPattern(matrix, reserved, 0, dim - 7)

        // 2. Alignment patterns
        if (spec.alignPos.isNotEmpty()) {
            for (r in spec.alignPos) {
                for (c in spec.alignPos) {
                    if ((r == 6 && c == 6) || (r == 6 && c == dim - 7) || (r == dim - 7 && c == 6)) continue
                    placeAlignmentPattern(matrix, reserved, r - 2, c - 2)
                }
            }
        }

        // 3. Timing patterns
        for (i in 0 until dim) {
            if (!reserved[6][i]) {
                matrix[6][i] = (i % 2 == 0)
                reserved[6][i] = true
            }
            if (!reserved[i][6]) {
                matrix[i][6] = (i % 2 == 0)
                reserved[i][6] = true
            }
        }

        // 4. Dark module
        matrix[dim - 8][8] = true
        reserved[dim - 8][8] = true

        // 5. Reserve format info
        for (i in 0..8) {
            reserved[8][i] = true
            reserved[i][8] = true
            reserved[dim - 1 - i][8] = true
            reserved[8][dim - 1 - i] = true
        }

        // 6. Encode data
        val dataBits = mutableListOf<Boolean>()
        // Mode indicator: 0100 for Byte mode
        addBits(dataBits, 4, 4)
        // Character count
        addBits(dataBits, bytes.size, 8)
        // Text bytes
        for (b in bytes) {
            addBits(dataBits, b.toInt() and 0xFF, 8)
        }
        // Terminator
        val maxDataBits = spec.dataCapacityBytes * 8
        val termLen = minOf(4, maxDataBits - dataBits.size)
        if (termLen > 0) {
            addBits(dataBits, 0, termLen)
        }
        // Pad to byte boundary
        while (dataBits.size % 8 != 0 && dataBits.size < maxDataBits) {
            dataBits.add(false)
        }
        // Pad codewords 0xEC, 0x11
        var padByte = 0xEC
        while (dataBits.size < maxDataBits) {
            addBits(dataBits, padByte, 8)
            padByte = if (padByte == 0xEC) 0x11 else 0xEC
        }

        val dataCodewords = IntArray(spec.dataCapacityBytes)
        for (i in 0 until spec.dataCapacityBytes) {
            var v = 0
            for (b in 0 until 8) {
                if (dataBits[i * 8 + b]) v = v or (1 shl (7 - b))
            }
            dataCodewords[i] = v
        }

        // 7. Reed Solomon Error Correction
        val ecCodewords = generateReedSolomonEC(dataCodewords, spec.ecCodewords)

        val allBits = mutableListOf<Boolean>()
        for (cw in dataCodewords) addBits(allBits, cw, 8)
        for (cw in ecCodewords) addBits(allBits, cw, 8)

        // 8. Place bits into matrix
        var bitIdx = 0
        var right = dim - 1
        while (right > 0) {
            if (right == 6) right-- // Skip timing column
            val cols = intArrayOf(right, right - 1)
            val goingUp = ((dim - 1 - right) / 2) % 2 == 0

            val rowRange = if (goingUp) (dim - 1 downTo 0) else (0 until dim)
            for (row in rowRange) {
                for (col in cols) {
                    if (!reserved[row][col]) {
                        val bit = if (bitIdx < allBits.size) allBits[bitIdx++] else false
                        // Mask 0: (row + col) % 2 == 0
                        val maskCondition = ((row + col) % 2 == 0)
                        matrix[row][col] = bit xor maskCondition
                    }
                }
            }
            right -= 2
        }

        // 9. Format Info (Mask 0, Level M = 000000000000000 XOR 101010000010010 = 101010000010010)
        placeFormatInfo(matrix, 0x5412) // Format info for Level M + Mask 0

        return matrix
    }

    private fun placeFinderPattern(
        matrix: Array<BooleanArray>,
        reserved: Array<BooleanArray>,
        startRow: Int,
        startCol: Int
    ) {
        for (r in -1..7) {
            for (c in -1..7) {
                val row = startRow + r
                val col = startCol + c
                if (row in matrix.indices && col in matrix[0].indices) {
                    reserved[row][col] = true
                    if (r in 0..6 && c in 0..6) {
                        matrix[row][col] = (r == 0 || r == 6 || c == 0 || c == 6 || (r in 2..4 && c in 2..4))
                    } else {
                        matrix[row][col] = false
                    }
                }
            }
        }
    }

    private fun placeAlignmentPattern(
        matrix: Array<BooleanArray>,
        reserved: Array<BooleanArray>,
        startRow: Int,
        startCol: Int
    ) {
        for (r in 0..4) {
            for (c in 0..4) {
                val row = startRow + r
                val col = startCol + c
                if (row in matrix.indices && col in matrix[0].indices && !reserved[row][col]) {
                    reserved[row][col] = true
                    matrix[row][col] = (r == 0 || r == 4 || c == 0 || c == 4 || (r == 2 && c == 2))
                }
            }
        }
    }

    private fun placeFormatInfo(matrix: Array<BooleanArray>, formatBits: Int) {
        val dim = matrix.size
        for (i in 0 until 15) {
            val bit = ((formatBits shr i) and 1) == 1
            // Top-left
            when {
                i < 6 -> matrix[8][i] = bit
                i == 6 -> matrix[8][7] = bit
                i == 7 -> matrix[8][8] = bit
                i == 8 -> matrix[7][8] = bit
                else -> matrix[14 - i][8] = bit
            }
            // Bottom-left and Top-right
            if (i < 8) {
                matrix[dim - 1 - i][8] = bit
            } else {
                matrix[8][dim - 15 + i] = bit
            }
        }
    }

    private fun addBits(bits: MutableList<Boolean>, value: Int, numBits: Int) {
        for (i in numBits - 1 downTo 0) {
            bits.add(((value shr i) and 1) == 1)
        }
    }

    private fun generateReedSolomonEC(data: IntArray, ecCount: Int): IntArray {
        val gfSize = 256
        val exp = IntArray(gfSize)
        val log = IntArray(gfSize)
        var x = 1
        for (i in 0 until 255) {
            exp[i] = x
            log[x] = i
            x = x shl 1
            if (x >= 256) x = x xor 0x11D
        }
        for (i in 255 until 512) {
            exp[i] = exp[i - 255]
        }

        fun gfMul(a: Int, b: Int): Int {
            if (a == 0 || b == 0) return 0
            return exp[log[a] + log[b]]
        }

        // Compute generator polynomial
        var gen = intArrayOf(1)
        for (i in 0 until ecCount) {
            val nextGen = IntArray(gen.size + 1)
            val alphaPower = exp[i]
            for (j in gen.indices) {
                nextGen[j] = nextGen[j] xor gfMul(gen[j], alphaPower)
                nextGen[j + 1] = nextGen[j + 1] xor gen[j]
            }
            gen = nextGen
        }

        // Division
        val res = IntArray(ecCount)
        for (d in data) {
            val factor = d xor res[0]
            System.arraycopy(res, 1, res, 0, ecCount - 1)
            res[ecCount - 1] = 0
            if (factor != 0) {
                for (j in 0 until ecCount) {
                    res[j] = res[j] xor gfMul(gen[j], factor)
                }
            }
        }
        return res
    }
}
