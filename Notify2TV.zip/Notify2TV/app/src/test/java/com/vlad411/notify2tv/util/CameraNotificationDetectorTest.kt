package com.vlad411.notify2tv.util

import com.vlad411.notify2tv.model.NotificationPayload
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CameraNotificationDetectorTest {

    @Test
    fun testEufyCameraNotificationByPackage() {
        val payload1 = NotificationPayload(
            id = "eufy_1",
            appName = "Eufy Security",
            packageName = "com.oceanwing.moredays",
            title = "Front Door Camera",
            body = "Motion detected"
        )
        assertTrue(CameraNotificationDetector.isCameraNotification(payload1))

        val payload2 = NotificationPayload(
            id = "eufy_2",
            appName = "eufy",
            packageName = "com.eufylife.smarthome",
            title = "Backyard",
            body = "Someone was spotted"
        )
        assertTrue(CameraNotificationDetector.isCameraNotification(payload2))
    }

    @Test
    fun testCameraNotificationByKeywords() {
        val payloadRing = NotificationPayload(
            id = "ring_1",
            appName = "Ring",
            packageName = "com.ringapp",
            title = "Front Door",
            body = "Person detected at Front Door"
        )
        assertTrue(CameraNotificationDetector.isCameraNotification(payloadRing))

        val payloadWyze = NotificationPayload(
            id = "wyze_1",
            appName = "Wyze",
            packageName = "com.wyze.wyzeapp",
            title = "Garage Cam",
            body = "Vehicle spotted in driveway"
        )
        assertTrue(CameraNotificationDetector.isCameraNotification(payloadWyze))

        val payloadTapo = NotificationPayload(
            id = "tapo_1",
            appName = "Tapo",
            packageName = "com.tplink.tapo",
            title = "Doorbell Alert",
            body = "Package delivered"
        )
        assertTrue(CameraNotificationDetector.isCameraNotification(payloadTapo))
    }

    @Test
    fun testNonCameraNotification() {
        val payloadWhatsapp = NotificationPayload(
            id = "wa_1",
            appName = "WhatsApp",
            packageName = "com.whatsapp",
            title = "Alice",
            body = "Hey, are we still meeting today at 5?"
        )
        assertFalse(CameraNotificationDetector.isCameraNotification(payloadWhatsapp))

        val payloadGmail = NotificationPayload(
            id = "gm_1",
            appName = "Gmail",
            packageName = "com.google.android.gm",
            title = "Weekly Newsletter",
            body = "Check out our latest updates!"
        )
        assertFalse(CameraNotificationDetector.isCameraNotification(payloadGmail))
    }
}
