package com.vlad411.notify2tv.service

import com.vlad411.notify2tv.model.CallPayload
import com.vlad411.notify2tv.model.CallType
import com.vlad411.notify2tv.model.NotificationActionPayload
import com.vlad411.notify2tv.model.NotificationPayload
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class TvReceiverManagerTest {

    @Test
    fun testOverlayStateNotificationPayload() {
        val notificationPayload = NotificationPayload(
            id = UUID.randomUUID().toString(),
            appName = "TestApp",
            packageName = "com.example.test",
            title = "Test Title",
            body = "Test Body",
            actions = listOf(
                NotificationActionPayload("act_1", "Reply", isQuickReply = true)
            )
        )

        val overlayState = OverlayState.NotificationOverlay(
            id = notificationPayload.id,
            payload = notificationPayload
        )

        assertEquals(notificationPayload.id, overlayState.id)
        assertEquals("TestApp", overlayState.payload.appName)
        assertEquals("Test Title", overlayState.payload.title)
        assertEquals(1, overlayState.payload.actions.size)
    }

    @Test
    fun testOverlayStateCallPayload() {
        val callPayload = CallPayload(
            id = UUID.randomUUID().toString(),
            callType = CallType.INCOMING,
            callerName = "Alice Smith",
            callerNumber = "+1234567890"
        )

        val overlayState = OverlayState.CallOverlay(
            id = callPayload.id,
            payload = callPayload
        )

        assertEquals(callPayload.id, overlayState.id)
        assertEquals("Alice Smith", overlayState.payload.callerName)
        assertEquals(CallType.INCOMING, overlayState.payload.callType)
    }

    @Test
    fun testPairedDeviceInfoDataClass() {
        val info = PairedDeviceInfo(
            deviceId = "dev_123",
            deviceName = "Pixel 8",
            ip = "192.168.1.50"
        )

        assertEquals("dev_123", info.deviceId)
        assertEquals("Pixel 8", info.deviceName)
        assertEquals("192.168.1.50", info.ip)
    }

    @Test
    fun testOverlayStateCreationDefaults() {
        val payload = NotificationPayload(
            id = "test_id_123",
            appName = "Notify2TV",
            packageName = "com.vlad411.notify2tv",
            title = "Test Title",
            body = "Test Body"
        )
        val overlay = OverlayState.NotificationOverlay(id = payload.id, payload = payload)
        assertEquals("test_id_123", overlay.id)
        assertTrue(overlay.createdAt > 0)
    }

    @Test
    fun testOverlayStateLargeImageOverlay() {
        val payload = NotificationPayload(
            id = "camera_notif_100",
            appName = "Security Cam",
            packageName = "com.vlad411.notify2tv.camera",
            title = "Motion Detected at Front Door",
            body = "Person detected in driveway.",
            bigPictureBase64 = "base64sampledata"
        )

        val largeImageOverlay = OverlayState.LargeImageOverlay(payload)
        assertEquals("camera_notif_100", largeImageOverlay.id)
        assertEquals("Security Cam", largeImageOverlay.payload.appName)
        assertEquals("Motion Detected at Front Door", largeImageOverlay.payload.title)
        assertTrue(largeImageOverlay.createdAt > 0)

        val companionOverlay = OverlayState.LargeImage(payload)
        assertEquals("camera_notif_100", companionOverlay.id)
    }

    @Test
    fun testBannerAlphaCalculation() {
        val transparency0 = 0
        val alpha0 = 1.0f - (transparency0.coerceIn(0, 100) / 100f)
        assertEquals(1.0f, alpha0, 0.001f)

        val transparency20 = 20
        val alpha20 = 1.0f - (transparency20.coerceIn(0, 100) / 100f)
        assertEquals(0.8f, alpha20, 0.001f)

        val transparency100 = 100
        val alpha100 = 1.0f - (transparency100.coerceIn(0, 100) / 100f)
        assertEquals(0.0f, alpha100, 0.001f)
    }
}
