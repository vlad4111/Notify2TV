 # Project Plan

An Android application that forwards notifications from a mobile device immediately to an Android TV. Features: 1. Forward mobile notifications in real time to Android TV. 2. Support notification images, big pictures, and application icons/logos. 3. Intercept and display incoming and outgoing phone call alerts/notifications on the TV. 4. Easy setup / pairing mechanism between mobile phone and TV receiver.

## Project Brief

# Project Brief: Notify2TV

## Features
1. **Device Pairing & Connection Setup**: Simple QR code or PIN code pairing mechanism to connect the mobile phone app to the Android TV receiver over the local network.
2. **Real-time Notification Forwarding**: Intercept mobile notifications using `NotificationListenerService` and instantly stream them to the paired Android TV.
3. **Rich Media Notification Support**: Transmit and render application icons, notification titles, text content, and big picture image attachments on the TV.
4. **Incoming & Outgoing Call Alerts**: Monitor telephony states to display immediate overlay call alerts (incoming/outgoing caller ID) on the TV screen.

## High-Level Tech Stack
* **Programming Language**: Kotlin
* **UI Framework**: Jetpack Compose
* **Navigation**: Jetpack Navigation 3 (state-driven navigation)
* **Adaptive Strategy**: Compose Material Adaptive library
* **Asynchronous & Reactive**: Kotlin Coroutines & Flow
* **Communication Layer**: Ktor / WebSockets (real-time local socket streaming between mobile client and TV receiver)
* **Android System APIs**: `NotificationListenerService` & Telephony Manager APIs

## Implementation Steps
**Total Duration:** 24m 57s

### Task_1_CoreNetworkingAndModels: Set up shared data models (NotificationPayload, CallPayload, PairingPayload) and local network communication layer using Ktor WebSockets for pairing and streaming between mobile client and TV receiver.
- **Status:** COMPLETED
- **Updates:** Shared data models (NotificationPayload, CallPayload, PairingPayload, NetworkMessage) and Ktor WebSocket server/client modules implemented. Ktor 3.0 WebSockets dependencies added. Unit tests written and verified with ./gradlew testDebugUnitTest assembleDebug.
- **Acceptance Criteria:**
  - Data models created for payloads
  - Ktor WebSocket client and server modules implemented
  - build pass
- **Duration:** 5m 36s

### Task_2_MobileAppNotificationAndCallListener: Implement Mobile app features: NotificationListenerService to intercept notifications/media, Telephony listener for phone call alerts, and mobile UI for pairing and service toggling.
- **Status:** COMPLETED
- **Updates:** Implemented NotificationListenerService (TvNotificationListenerService) to intercept notifications and media, PhoneCallReceiver & ContactsHelper for call monitoring, NsdDiscoveryManager for TV auto-discovery, MobileServiceManager state manager, and MobileMainScreen Compose UI with pairing, permissions, settings, and live activity logs. Verified build and tests with ./gradlew testDebugUnitTest assembleDebug.
- **Acceptance Criteria:**
  - NotificationListenerService intercepts notifications and rich media
  - Telephony state listener captures call events
  - Mobile pairing screen implemented
  - build pass
- **Duration:** 8m 54s

### Task_3_TVReceiverAppAndOverlayUI: Implement Android TV Receiver features and Jetpack Compose UI: TV pairing screen, local WebSocket listener, and overlay banner popups for incoming notifications, icons, and call alerts.
- **Status:** COMPLETED
- **Updates:** Implemented TV Receiver UI (TvMainScreen), auto-generated QR code generator (QrCodeGenerator), NSD publishing (NsdPublisher), TV server foreground service (TvServerService), TV Notification & Call overlay UI (TvOverlayBanner, TvOverlayService), auto-boot receiver (TvBootReceiver), and unified MainActivity supporting Mobile and TV modes. Verified with ./gradlew testDebugUnitTest assembleDebug.
- **Acceptance Criteria:**
  - TV UI displays pairing code/QR and socket status
  - Overlay banner renders notifications, application icons, rich media images, and call alerts
  - build pass
- **Duration:** 4m 25s

### Task_4_RunAndVerify: Run and Verify: Instruct critic_agent to build the project, run tests, verify application stability (no crashes), confirm alignment with user requirements for notification/call forwarding, and report any critical UI issues.
- **Status:** COMPLETED
- **Updates:** Verified build, unit test suite (13/13 tests passing across NetworkMessageTest, WebSocketCommunicationTest, TvReceiverManagerTest, MobileServiceManagerTest, PhoneCallReceiverTest, QrCodeGeneratorTest), and functional implementation of Mobile Sender and TV Receiver modes. Application builds without errors with assembleDebug.
- **Acceptance Criteria:**
  - make sure all existing tests pass
  - build pass
  - app does not crash
  - application stability verified
- **Duration:** 6m 2s

