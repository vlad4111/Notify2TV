package com.vlad411.notify2tv.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
enum class PairingStatus {
    @SerialName("PENDING") PENDING,
    @SerialName("ACCEPTED") ACCEPTED,
    @SerialName("REJECTED") REJECTED,
    @SerialName("SUCCESS") SUCCESS,
    @SerialName("FAILED") FAILED
}

@Serializable
enum class ClientType {
    @SerialName("MOBILE") MOBILE,
    @SerialName("TV") TV
}

@Serializable
data class PairingPayload(
    @SerialName("pairing_code") val pairingCode: String,
    @SerialName("ip") val ip: String,
    @SerialName("port") val port: Int,
    @SerialName("device_id") val deviceId: String,
    @SerialName("device_name") val deviceName: String,
    @SerialName("client_type") val clientType: ClientType = ClientType.MOBILE,
    @SerialName("status") val status: PairingStatus = PairingStatus.PENDING,
    @SerialName("auth_token") val authToken: String? = null
)
