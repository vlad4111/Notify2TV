package com.vlad411.notify2tv.util

import com.vlad411.notify2tv.model.NotificationPayload

object CameraNotificationDetector {

    val CAMERA_PACKAGES = listOf(
        "eufy",
        "com.oceanwing.moredays",
        "com.eufylife",
        "security",
        "camera",
        "ring",
        "nest",
        "wyze",
        "arlo",
        "blink",
        "reolink",
        "doorbell",
        "tapo",
        "tuya",
        "smartlife",
        "hikvision",
        "dahua",
        "yi"
    )

    val CAMERA_KEYWORDS = listOf(
        "motion",
        "spotted",
        "camera",
        "doorbell",
        "person",
        "human",
        "vehicle",
        "package",
        "detect",
        "front door",
        "backyard",
        "driveway",
        "garage",
        "eufy"
    )

    fun isCameraNotification(payload: NotificationPayload): Boolean {
        return isCameraNotification(
            packageName = payload.packageName,
            appName = payload.appName,
            title = payload.title,
            body = payload.body
        )
    }

    fun isCameraNotification(
        packageName: String,
        appName: String,
        title: String,
        body: String
    ): Boolean {
        val pkg = packageName.lowercase()
        val app = appName.lowercase()
        val t = title.lowercase()
        val b = body.lowercase()

        val matchesPackage = CAMERA_PACKAGES.any { pkg.contains(it) }
        val matchesKeyword = CAMERA_KEYWORDS.any { keyword ->
            app.contains(keyword) || t.contains(keyword) || b.contains(keyword)
        }

        return matchesPackage || matchesKeyword
    }
}
