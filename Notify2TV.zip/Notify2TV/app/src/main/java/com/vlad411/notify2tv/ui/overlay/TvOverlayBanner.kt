package com.vlad411.notify2tv.ui.overlay

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.CallMade
import androidx.compose.material.icons.automirrored.rounded.PhoneCallback
import androidx.compose.material.icons.automirrored.rounded.PhoneMissed
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CallEnd
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vlad411.notify2tv.model.BannerPosition
import com.vlad411.notify2tv.model.CallPayload
import com.vlad411.notify2tv.model.CallType
import com.vlad411.notify2tv.model.NotificationPayload
import com.vlad411.notify2tv.network.NetworkUtils
import com.vlad411.notify2tv.service.OverlayState
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TvOverlayBanner(
    overlayState: OverlayState?,
    onDismiss: () -> Unit,
    onActionClicked: (actionId: String, notificationId: String) -> Unit,
    modifier: Modifier = Modifier,
    bannerPosition: BannerPosition = BannerPosition.TOP_RIGHT,
    timeoutSeconds: Int = 7,
    transparencyPercent: Int = 0
) {
    val focusRequester = remember { FocusRequester() }
    var isContainerFocused by remember { mutableStateOf(false) }
    var isAnyChildFocused by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(1f) }

    val isPaused = isContainerFocused || isAnyChildFocused

    LaunchedEffect(overlayState, isPaused, timeoutSeconds) {
        if (overlayState == null) return@LaunchedEffect
        progress = 1f
        val totalMs = timeoutSeconds * 1000L
        val intervalMs = 100L
        var elapsedMs = 0L

        while (elapsedMs < totalMs) {
            if (!isPaused) {
                elapsedMs += intervalMs
                progress = (1f - (elapsedMs.toFloat() / totalMs.toFloat())).coerceIn(0f, 1f)
            }
            delay(intervalMs)
        }
        onDismiss()
    }

    LaunchedEffect(overlayState) {
        if (overlayState != null) {
            runCatching {
                delay(150)
                focusRequester.requestFocus()
            }
        }
    }

    val isTopPosition = bannerPosition == BannerPosition.TOP_LEFT || bannerPosition == BannerPosition.TOP_RIGHT
    val isLargeCameraBanner = overlayState is OverlayState.LargeImageOverlay
    val hasImageAttachment = (overlayState as? OverlayState.NotificationOverlay)?.payload?.bigPictureBase64?.isNotBlank() == true

    val bannerAlpha = 1.0f - (transparencyPercent.coerceIn(0, 100) / 100f)

    val bannerWidthModifier = if (isLargeCameraBanner) {
        Modifier.widthIn(min = 520.dp, max = 680.dp)
    } else if (hasImageAttachment) {
        Modifier.width(460.dp)
    } else {
        Modifier.width(400.dp)
    }

    AnimatedVisibility(
        visible = overlayState != null,
        enter = slideInVertically { if (isTopPosition) -it else it } + fadeIn(),
        exit = slideOutVertically { if (isTopPosition) -it else it } + fadeOut(),
        modifier = modifier.wrapContentSize()
    ) {
        if (overlayState != null) {
            Surface(
                modifier = Modifier
                    .graphicsLayer { alpha = bannerAlpha }
                    .then(bannerWidthModifier)
                    .wrapContentHeight()
                    .focusRequester(focusRequester)
                    .onFocusChanged { isContainerFocused = it.isFocused }
                    .onKeyEvent { keyEvent ->
                        if (keyEvent.type == KeyEventType.KeyUp) {
                            when (keyEvent.key) {
                                Key.DirectionCenter, Key.Enter, Key.NumPadEnter, Key.Back, Key.Escape -> {
                                    onDismiss()
                                    true
                                }
                                else -> false
                            }
                        } else {
                            false
                        }
                    }
                    .focusable(),
                shape = RoundedCornerShape(16.dp),
                color = if (isLargeCameraBanner) Color(0xFF14141F) else Color(0xFF1E1E2C),
                contentColor = Color(0xFFE6E1E5),
                tonalElevation = 8.dp,
                shadowElevation = 12.dp,
                border = if (isContainerFocused || isAnyChildFocused) {
                    BorderStroke(3.dp, MaterialTheme.colorScheme.primary)
                } else if (isLargeCameraBanner) {
                    BorderStroke(1.5.dp, Color(0xFFFF5252).copy(alpha = 0.6f))
                } else {
                    BorderStroke(1.dp, Color(0xFF38384A))
                }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight()
                ) {
                    when (overlayState) {
                        is OverlayState.NotificationOverlay -> {
                            NotificationOverlayContent(
                                payload = overlayState.payload,
                                onDismiss = onDismiss,
                                onActionClicked = onActionClicked,
                                onFocusChange = { isAnyChildFocused = it }
                            )
                        }
                        is OverlayState.CallOverlay -> {
                            CallOverlayContent(
                                payload = overlayState.payload,
                                onDismiss = onDismiss,
                                onFocusChange = { isAnyChildFocused = it }
                            )
                        }
                        is OverlayState.LargeImageOverlay -> {
                            LargeImageOverlayContent(
                                payload = overlayState.payload,
                                onDismiss = onDismiss,
                                onActionClicked = onActionClicked,
                                onFocusChange = { isAnyChildFocused = it }
                            )
                        }
                    }

                    // Countdown progress bar at bottom of overlay
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp),
                        color = if (isLargeCameraBanner) Color(0xFFFF5252) else MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun NotificationOverlayContent(
    payload: NotificationPayload,
    onDismiss: () -> Unit,
    onActionClicked: (actionId: String, notificationId: String) -> Unit,
    onFocusChange: (Boolean) -> Unit
) {
    val appIconBitmap = remember(payload.appIconBase64) {
        runCatching {
            payload.appIconBase64?.takeIf { it.isNotBlank() }?.let { NetworkUtils.base64ToBitmap(it) }
        }.getOrNull()
    }
    val safeAppIconImageBitmap = remember(appIconBitmap) {
        appIconBitmap?.let { bmp -> runCatching { bmp.asImageBitmap() }.getOrNull() }
    }

    val bigPictureBitmap = remember(payload.bigPictureBase64) {
        runCatching {
            payload.bigPictureBase64?.takeIf { it.isNotBlank() }?.let { NetworkUtils.base64ToBitmap(it) }
        }.getOrNull()
    }
    val safeBigPictureImageBitmap = remember(bigPictureBitmap) {
        bigPictureBitmap?.let { bmp -> runCatching { bmp.asImageBitmap() }.getOrNull() }
    }

    var isCloseFocused by remember { mutableStateOf(false) }
    var isDismissBtnFocused by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .padding(16.dp)
    ) {
        // Header Row: App Icon + App Name + Dismiss button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (safeAppIconImageBitmap != null) {
                Image(
                    bitmap = safeAppIconImageBitmap,
                    contentDescription = payload.appName,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(10.dp)),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = payload.appName,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .onFocusChanged {
                        isCloseFocused = it.isFocused
                        onFocusChange(it.isFocused || isDismissBtnFocused)
                    }
                    .border(
                        width = if (isCloseFocused) 2.dp else 0.dp,
                        color = if (isCloseFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                        shape = CircleShape
                    )
                    .focusable()
            ) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "Dismiss",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Title
        if (payload.title.isNotBlank()) {
            Text(
                text = payload.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
        }

        // Body
        if (payload.body.isNotBlank()) {
            Text(
                text = payload.body,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 4,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Big Picture Image Attachment
        if (safeBigPictureImageBitmap != null) {
            Image(
                bitmap = safeBigPictureImageBitmap,
                contentDescription = "Notification Image",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Actions Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            payload.actions.take(2).forEach { action ->
                var isActionFocused by remember { mutableStateOf(false) }
                Button(
                    onClick = { onActionClicked(action.actionId, payload.id) },
                    modifier = Modifier
                        .padding(start = 8.dp)
                        .onFocusChanged {
                            isActionFocused = it.isFocused
                            onFocusChange(it.isFocused || isDismissBtnFocused || isCloseFocused)
                        }
                        .border(
                            width = if (isActionFocused) 2.dp else 0.dp,
                            color = if (isActionFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                            shape = RoundedCornerShape(20.dp)
                        )
                        .focusable(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                ) {
                    Text(text = action.title, fontSize = 13.sp)
                }
            }

            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier
                    .padding(start = 8.dp)
                    .onFocusChanged {
                        isDismissBtnFocused = it.isFocused
                        onFocusChange(it.isFocused || isCloseFocused)
                    }
                    .border(
                        width = if (isDismissBtnFocused) 2.dp else 0.dp,
                        color = if (isDismissBtnFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .focusable()
            ) {
                Text(text = "Dismiss", fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun LargeImageOverlayContent(
    payload: NotificationPayload,
    onDismiss: () -> Unit,
    onActionClicked: (actionId: String, notificationId: String) -> Unit,
    onFocusChange: (Boolean) -> Unit
) {
    val appIconBitmap = remember(payload.appIconBase64) {
        runCatching {
            payload.appIconBase64?.takeIf { it.isNotBlank() }?.let { NetworkUtils.base64ToBitmap(it) }
        }.getOrNull()
    }
    val safeAppIconImageBitmap = remember(appIconBitmap) {
        appIconBitmap?.let { bmp -> runCatching { bmp.asImageBitmap() }.getOrNull() }
    }

    val cameraImageBitmap = remember(payload.bigPictureBase64, payload.appIconBase64) {
        runCatching {
            (payload.bigPictureBase64 ?: payload.appIconBase64)?.takeIf { it.isNotBlank() }?.let { NetworkUtils.base64ToBitmap(it) }
        }.getOrNull()
    }
    val safeCameraImageBitmap = remember(cameraImageBitmap) {
        cameraImageBitmap?.let { bmp -> runCatching { bmp.asImageBitmap() }.getOrNull() }
    }

    var isCloseFocused by remember { mutableStateOf(false) }
    var isDismissBtnFocused by remember { mutableStateOf(false) }

    val formattedTime = remember {
        SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .padding(18.dp)
    ) {
        // Camera Header Badge Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (safeAppIconImageBitmap != null) {
                Image(
                    bitmap = safeAppIconImageBitmap,
                    contentDescription = payload.appName,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.width(8.dp))
            }

            // Camera Header Badge
            Surface(
                color = Color(0xFFFF3D00).copy(alpha = 0.2f),
                shape = CircleShape,
                border = BorderStroke(1.dp, Color(0xFFFF3D00))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Videocam,
                        contentDescription = null,
                        tint = Color(0xFFFF5252),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "📷 CAMERA ALERT • ${payload.appName.uppercase()}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFF5252)
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Text(
                text = formattedTime,
                fontSize = 12.sp,
                color = Color(0xFFA0A0B0),
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.weight(1f))

            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .onFocusChanged {
                        isCloseFocused = it.isFocused
                        onFocusChange(it.isFocused || isDismissBtnFocused)
                    }
                    .border(
                        width = if (isCloseFocused) 2.dp else 0.dp,
                        color = if (isCloseFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                        shape = CircleShape
                    )
                    .focusable()
            ) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "Dismiss",
                    tint = Color(0xFFA0A0B0)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Camera Subtitle / Title
        if (payload.title.isNotBlank()) {
            Text(
                text = payload.title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (payload.body.isNotBlank()) {
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = payload.body,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFC0C0D0),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Large Camera Image View (height 340.dp)
        if (safeCameraImageBitmap != null) {
            Image(
                bitmap = safeCameraImageBitmap,
                contentDescription = "Camera Snapshot",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFF38384A), RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Fit
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF222232)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Rounded.Videocam,
                        contentDescription = null,
                        tint = Color(0xFF808095),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Security Camera Snapshot",
                        color = Color(0xFF808095),
                        fontSize = 14.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Actions / Dismiss
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            payload.actions.take(2).forEach { action ->
                var isActionFocused by remember { mutableStateOf(false) }
                Button(
                    onClick = { onActionClicked(action.actionId, payload.id) },
                    modifier = Modifier
                        .padding(start = 8.dp)
                        .onFocusChanged {
                            isActionFocused = it.isFocused
                            onFocusChange(it.isFocused || isDismissBtnFocused || isCloseFocused)
                        }
                        .border(
                            width = if (isActionFocused) 2.dp else 0.dp,
                            color = if (isActionFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                            shape = RoundedCornerShape(20.dp)
                        )
                        .focusable(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF2D2D42),
                        contentColor = Color.White
                    )
                ) {
                    Text(text = action.title, fontSize = 13.sp)
                }
            }

            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier
                    .padding(start = 8.dp)
                    .onFocusChanged {
                        isDismissBtnFocused = it.isFocused
                        onFocusChange(it.isFocused || isCloseFocused)
                    }
                    .border(
                        width = if (isDismissBtnFocused) 2.dp else 0.dp,
                        color = if (isDismissBtnFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .focusable()
            ) {
                Text(text = "Dismiss Banner", fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun CallOverlayContent(
    payload: CallPayload,
    onDismiss: () -> Unit,
    onFocusChange: (Boolean) -> Unit
) {
    val avatarBitmap = remember(payload.callerAvatarBase64) {
        runCatching {
            payload.callerAvatarBase64?.takeIf { it.isNotBlank() }?.let { NetworkUtils.base64ToBitmap(it) }
        }.getOrNull()
    }
    val safeAvatarImageBitmap = remember(avatarBitmap) {
        avatarBitmap?.let { bmp -> runCatching { bmp.asImageBitmap() }.getOrNull() }
    }

    var isCloseFocused by remember { mutableStateOf(false) }
    var isDismissBtnFocused by remember { mutableStateOf(false) }

    val (badgeColor, badgeText, badgeIcon) = when (payload.callType) {
        CallType.INCOMING -> Triple(
            Color(0xFF2E7D32),
            "INCOMING CALL",
            Icons.Rounded.Call
        )
        CallType.OUTGOING -> Triple(
            Color(0xFF1565C0),
            "OUTGOING CALL",
            Icons.AutoMirrored.Rounded.CallMade
        )
        CallType.MISSED -> Triple(
            Color(0xFFC62828),
            "MISSED CALL",
            Icons.AutoMirrored.Rounded.PhoneMissed
        )
        CallType.ENDED -> Triple(
            Color(0xFF616161),
            "CALL ENDED",
            Icons.Rounded.CallEnd
        )
        CallType.REJECTED -> Triple(
            Color(0xFFD84315),
            "CALL REJECTED",
            Icons.AutoMirrored.Rounded.PhoneCallback
        )
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .padding(20.dp)
    ) {
        // Top Call Type Badge
        Surface(
            color = badgeColor.copy(alpha = 0.2f),
            shape = CircleShape,
            border = BorderStroke(1.dp, badgeColor),
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(
                    imageVector = badgeIcon,
                    contentDescription = null,
                    tint = badgeColor,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = badgeText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = badgeColor
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar
            if (safeAvatarImageBitmap != null) {
                Image(
                    bitmap = safeAvatarImageBitmap,
                    contentDescription = "Caller Avatar",
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                val displayName = payload.callerName ?: payload.callerNumber ?: "Unknown Caller"
                Text(
                    text = displayName,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                if (payload.callerNumber != null && payload.callerName != null) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = payload.callerNumber,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .onFocusChanged {
                        isCloseFocused = it.isFocused
                        onFocusChange(it.isFocused || isDismissBtnFocused)
                    }
                    .border(
                        width = if (isCloseFocused) 2.dp else 0.dp,
                        color = if (isCloseFocused) MaterialTheme.colorScheme.primary else Color.Transparent,
                        shape = CircleShape
                    )
                    .focusable()
            ) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "Dismiss Alert",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Button(
                onClick = onDismiss,
                modifier = Modifier
                    .onFocusChanged {
                        isDismissBtnFocused = it.isFocused
                        onFocusChange(it.isFocused || isCloseFocused)
                    }
                    .border(
                        width = if (isDismissBtnFocused) 3.dp else 0.dp,
                        color = if (isDismissBtnFocused) MaterialTheme.colorScheme.tertiary else Color.Transparent,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .focusable(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Text(text = "Dismiss Alert", fontWeight = FontWeight.Bold)
            }
        }
    }
}
